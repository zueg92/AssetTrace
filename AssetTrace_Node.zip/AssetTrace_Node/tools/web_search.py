import html
import json
import re
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from config import WEB_DIR


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def clean_html_text(text: str) -> str:
    text = re.sub(r"<.*?>", " ", text, flags=re.DOTALL)
    text = html.unescape(text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[àáâä]", "a", text)
    text = re.sub(r"[èéêë]", "e", text)
    text = re.sub(r"[ìíîï]", "i", text)
    text = re.sub(r"[òóôö]", "o", text)
    text = re.sub(r"[ùúûü]", "u", text)
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_")[:70] or "ricerca"


def web_search_duckduckgo(query: str, max_results: int = 5) -> Dict:
    encoded = urllib.parse.urlencode({"q": query})
    url = f"https://duckduckgo.com/html/?{encoded}"

    request = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0 AssetTraceNode/0.2"},
        method="GET",
    )

    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            raw = response.read().decode("utf-8", errors="ignore")
    except Exception as e:
        return {"ok": False, "query": query, "fetched_at": now(), "error": str(e), "results": []}

    pattern = re.compile(
        r'<a[^>]+class="result__a"[^>]+href="(?P<url>.*?)"[^>]*>(?P<title>.*?)</a>',
        re.DOTALL,
    )

    results: List[Dict[str, str]] = []
    for match in list(pattern.finditer(raw))[:max_results]:
        title = clean_html_text(match.group("title"))
        href = html.unescape(match.group("url"))
        parsed = urllib.parse.urlparse(href)
        qs = urllib.parse.parse_qs(parsed.query)
        if "uddg" in qs:
            href = qs["uddg"][0]
        results.append({"title": title, "url": href, "source": "duckduckgo_html"})

    return {"ok": True, "query": query, "fetched_at": now(), "results": results}


def format_web_context(web_data: Dict) -> str:
    if not web_data.get("ok"):
        return (
            "RICERCA WEB FALLITA\n"
            f"Query: {web_data.get('query')}\n"
            f"Errore: {web_data.get('error')}\n"
        )

    results = web_data.get("results", [])
    if not results:
        return (
            "RICERCA WEB ESEGUITA MA SENZA RISULTATI ESTRATTI\n"
            f"Query: {web_data.get('query')}\n"
            "Nota: il motore potrebbe aver cambiato HTML oppure non ci sono risultati leggibili.\n"
        )

    lines = [
        "RICERCA WEB — OSSERVAZIONE ESTERNA PARTE 4",
        f"Query: {web_data.get('query')}",
        f"Data ricerca: {web_data.get('fetched_at')}",
        "",
        "Risultati trovati:",
    ]
    for i, item in enumerate(results, start=1):
        lines.append(f"{i}. {item.get('title')}")
        lines.append(f"   URL: {item.get('url')}")
        lines.append(f"   Fonte tecnica: {item.get('source')}")
        lines.append("")

    lines.append(
        "Vincolo Parte 4: questi risultati sono segnali esterni, non verità. "
        "Valuta freschezza, affidabilità, contraddizioni e rischio."
    )
    return "\n".join(lines)


def save_web_json(query: str, web_data: Dict, antinea_answer: Optional[str] = None) -> Path:
    WEB_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = WEB_DIR / f"WEB-{timestamp}_{slugify(query)}.json"
    payload = {
        "timestamp": now(),
        "query": query,
        "web_data": web_data,
        "antinea_answer": antinea_answer,
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def extract_web_query(user_text: str) -> str:
    query = user_text.strip()
    removals = [
        "cerca online", "cerca su internet", "verifica online", "ricerca web",
        "controlla online", "guarda online", "fonti online", "aggiornato online",
    ]
    for removal in removals:
        query = re.sub(re.escape(removal), "", query, flags=re.IGNORECASE).strip()
    return query or user_text.strip()
