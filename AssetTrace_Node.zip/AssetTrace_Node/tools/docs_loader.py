import re
from datetime import datetime
from pathlib import Path
from typing import List

from config import DOCS_DIR, GUASTI_DIR, DOC_EXTENSIONS, MAX_DOC_CHARS, MAX_SINGLE_DOC_CHARS


def natural_sort_key(path: Path):
    text = path.name.lower()
    return [int(part) if part.isdigit() else part for part in re.split(r"(\d+)", text)]


def truncate_text(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + "\n\n[... testo abbreviato per non sovraccaricare Ollama ...]"


def discover_docs() -> List[Path]:
    DOCS_DIR.mkdir(parents=True, exist_ok=True)
    files: List[Path] = []
    for path in DOCS_DIR.iterdir():
        if not path.is_file():
            continue
        if path.name.startswith("."):
            continue
        if path.suffix.lower() not in DOC_EXTENSIONS:
            continue
        files.append(path)
    return sorted(files, key=natural_sort_key)


def load_docs_text(root: Path) -> str:
    parts = []
    files = discover_docs()

    if not files:
        return (
            "\n\n===== DOCS =====\n"
            "Nessun documento fondativo trovato. Inserisci file .md o .txt nella cartella docs/."
        )

    for path in files:
        text = truncate_text(path.read_text(encoding="utf-8", errors="ignore"), MAX_SINGLE_DOC_CHARS)
        stat = path.stat()
        modified = datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds")
        try:
            relative = path.relative_to(root)
        except ValueError:
            relative = path
        parts.append(
            f"\n\n===== {relative} | modificato: {modified} | {stat.st_size} byte =====\n{text}"
        )

    return truncate_text("\n".join(parts), MAX_DOC_CHARS)


def docs_status_lines() -> List[str]:
    files = discover_docs()
    lines = ["Documenti fondativi caricati da docs/:"]
    if not files:
        lines.append("- nessun documento .md o .txt trovato")
        return lines

    for path in files:
        stat = path.stat()
        modified = datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds")
        lines.append(f"- docs/{path.name} OK | {stat.st_size} byte | modificato: {modified}")
    return lines


def guasti_status_lines(root: Path) -> List[str]:
    lines = ["Knowledge base guasti:"]
    if not GUASTI_DIR.exists():
        lines.append("- cartella guasti MANCANTE")
        return lines

    files = sorted(GUASTI_DIR.rglob("*.md"))
    if not files:
        lines.append("- nessun file guasto trovato")
        return lines

    for path in files:
        try:
            rel = path.relative_to(root)
        except ValueError:
            rel = path
        lines.append(f"- {rel} OK")
    return lines
