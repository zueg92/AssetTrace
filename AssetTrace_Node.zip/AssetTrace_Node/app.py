import json
from datetime import datetime

from config import MODEL, ROOT, ensure_dirs
from core.governance import governance_check, should_auto_web
from core.ollama_client import ask_ollama, check_ollama
from core.prompt_builder import build_messages
from memory.guasti import add_guasto_interactive
from memory.patterns import format_health_table, format_patterns_report
from memory.parco_macchine import (
    add_machine_event,
    add_machine_interactive,
    format_machine_detail,
    format_machines_table,
    get_machine,
    list_machine_events,
    list_machines,
    search_machines,
    seed_example_machines_if_empty,
    update_machine_status,
)
from memory.store import init_db, load_recent_chat, save_chat, save_web_observation_db
from tools.docs_loader import docs_status_lines, guasti_status_lines
from tools.web_search import extract_web_query, format_web_context, save_web_json, web_search_duckduckgo


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def print_docs_status() -> None:
    print()
    for line in docs_status_lines():
        print(line)
    print()
    for line in guasti_status_lines(ROOT):
        print(line)


def ask_antinea(user_text: str, web_context: str | None = None) -> str:
    governance = governance_check(user_text)
    recent = load_recent_chat(8)
    messages = build_messages(user_text, recent, governance, web_context=web_context)
    return ask_ollama(messages)


def run_web_flow(user_text: str, query: str | None = None):
    query = query or extract_web_query(user_text)
    print("\nAssetTrace > attivo Parte 4: ricerca web real-time...")
    web_data = web_search_duckduckgo(query)
    web_context = format_web_context(web_data)
    answer = ask_antinea(user_text, web_context=web_context)
    saved_json = save_web_json(query, web_data, answer)
    save_web_observation_db(now(), query, bool(web_data.get("ok")), web_data, answer)
    save_chat(now(), user_text, answer)
    print("\nAssetTrace >")
    print(answer)
    print(f"\n[ricerca web salvata in: {saved_json}]")


def show_help() -> None:
    print("""
Comandi disponibili:

/docs
  Mostra tutti i documenti fondativi trovati automaticamente in docs/ e la knowledge base guasti.

/mem
  Mostra la memoria recente salvata nel database SQLite.

/macchine
  Mostra il parco macchine registrato con stato e criticità.

/health
  Mostra health index sintetico del parco macchine.

/patterns
  Analizza pattern globali, macchine fragili, eventi ricorrenti e termini ricorrenti.

/patterns <ID>
  Analizza pattern di una singola macchina. Esempio: /patterns MAC-001

/addmacchina
  Aggiunge una nuova macchina al parco macchine.

/macchina <ID o testo>
  Mostra il dettaglio di una macchina. Esempio: /macchina MAC-001 oppure /macchina Chiron

/stato <ID> <nuovo stato>
  Aggiorna lo stato di una macchina. Esempio: /stato MAC-001 manutenzione

/eventomacchina <ID>
  Aggiunge un evento manuale alla macchina: manutenzione, controllo, guasto, nota.

/addguasto
  Aggiunge un nuovo guasto nella cartella guasti/.

/web <query>
  Esegue una ricerca web reale e la passa ad AssetTrace come osservazione esterna Parte 4.
  Esempio:
  /web OctoPrint non si avvia automaticamente Raspberry Pi

/ollama
  Controlla se Ollama è raggiungibile e se il modello configurato è presente.

/reload
  Riscansiona manualmente la cartella docs/.

Nota:
  Anche senza /reload, AssetTrace rilegge docs/ a ogni domanda.
  Se modifichi o aggiungi un file .md, viene usato dal messaggio successivo.

/exit
  Chiude AssetTrace Node.
""")


def main() -> None:
    ensure_dirs()
    init_db()
    seed_example_machines_if_empty()

    print("=" * 60)
    print("ASSETTRACE NODE v2 — modulare")
    print("Modello:", MODEL)
    print("Comandi: /docs  /mem  /macchine  /health  /patterns  /macchina  /stato  /eventomacchina  /addmacchina  /addguasto  /web  /ollama  /help  /exit")
    print("=" * 60)
    print_docs_status()

    while True:
        user_text = input("\nTu > ").strip()
        if not user_text:
            continue

        if user_text.lower().strip() in ["analizza e rispondimi", "analizza", "rispondimi"]:
            print("\nLa frase è troppo generica. Usa per esempio:")
            print("/patterns")
            print("/health")
            print("/patterns MAC-001")
            print("Analizza lo stato della macchina MAC-001")
            continue

        if user_text == "/exit":
            print("AssetTrace Node chiuso.")
            break

        if user_text in ["/docs", "/reload"]:
            print_docs_status()
            continue

        if user_text == "/help":
            show_help()
            continue

        if user_text == "/mem":
            print(json.dumps(load_recent_chat(10), ensure_ascii=False, indent=2))
            continue

        if user_text == "/ollama":
            status = check_ollama()
            print("\nStato Ollama:")
            print(json.dumps(status, ensure_ascii=False, indent=2))
            if not status.get("ok"):
                print("\nOllama non risulta raggiungibile. Prova in PowerShell: ollama serve")
            elif not status.get("model_presente"):
                print("\nOllama è raggiungibile, ma manca il modello. Prova: ollama pull llama3.2:3b")
            else:
                print("\nOllama è raggiungibile e il modello configurato risulta presente.")
            continue

        # Aiuto rapido: se l'utente chiede in linguaggio naturale come cambiare lo stato,
        # non inviamo la frase a Ollama; mostriamo direttamente il comando interno.
        lower_text = user_text.lower()
        if (
            "modificare lo stato" in lower_text
            or "cambiare lo stato" in lower_text
            or "aggiornare lo stato" in lower_text
            or "modifica stato" in lower_text
            or "cambia stato" in lower_text
        ):
            print("\nPer modificare lo stato di una macchina usa:")
            print("/stato <ID_MACCHINA> <nuovo_stato>")
            print("\nEsempi:")
            print("/stato MAC-001 manutenzione")
            print("/stato MAC-001 operativa")
            print("/stato MAC-001 guasto")
            print("\nPer vedere gli ID disponibili:")
            print("/macchine")
            continue

        if user_text == "/health":
            print()
            print(format_health_table())
            continue

        if user_text.startswith("/patterns"):
            arg = user_text.replace("/patterns", "", 1).strip()
            print()
            print(format_patterns_report(arg or None))
            continue

        if user_text == "/macchine":
            print()
            print(format_machines_table(list_machines()))
            continue

        if user_text == "/addmacchina":
            machine_id = add_machine_interactive()
            print(f"\nMacchina aggiunta correttamente: {machine_id}")
            continue

        if user_text.startswith("/macchina"):
            arg = user_text.replace("/macchina", "", 1).strip()
            if not arg:
                print("\nUso: /macchina <ID o testo>")
                print("Esempio: /macchina MAC-001 oppure /macchina Chiron")
                continue

            machine = get_machine(arg)
            if machine is None:
                results = search_machines(arg)
                if len(results) == 1:
                    machine = results[0]
                elif len(results) > 1:
                    print("\nHo trovato più macchine:")
                    print(format_machines_table(results))
                    print("\nUsa /macchina MAC-XXX per aprirne una precisa.")
                    continue

            if machine is None:
                print("\nNessuna macchina trovata.")
                continue

            events = list_machine_events(machine["id"], limit=10)
            print()
            print(format_machine_detail(machine, events))
            continue

        if user_text.startswith("/stato"):
            parts = user_text.split(maxsplit=2)
            if len(parts) < 3:
                print("\nUso: /stato <ID> <nuovo stato>")
                print("Esempio: /stato MAC-001 manutenzione")
                continue
            ok = update_machine_status(parts[1], parts[2], note="Aggiornato da comando /stato")
            if ok:
                print(f"\nStato aggiornato per {parts[1]}: {parts[2]}")
            else:
                print("\nMacchina non trovata.")
            continue

        if user_text.startswith("/eventomacchina"):
            parts = user_text.split(maxsplit=1)
            if len(parts) < 2:
                print("\nUso: /eventomacchina <ID>")
                continue
            machine_id = parts[1].strip()
            if not get_machine(machine_id):
                print("\nMacchina non trovata.")
                continue
            print("\nTipo evento es. manutenzione, controllo, guasto, nota:")
            event_type = input("> ").strip() or "nota"
            print("\nTitolo evento:")
            title = input("> ").strip() or "Evento macchina"
            print("\nDescrizione:")
            description = input("> ").strip()
            print("\nImpatto es. basso, medio, alto:")
            impact = input("> ").strip() or "medio"
            add_machine_event(machine_id, event_type, title, description, impact)
            print("\nEvento aggiunto.")
            continue

        if user_text == "/addguasto":
            path = add_guasto_interactive()
            print("\nGuasto creato correttamente:")
            print(path)
            continue

        if user_text.startswith("/web"):
            query = user_text.replace("/web", "", 1).strip()
            if not query:
                print("\nUso: /web <query>")
                print("Esempio: /web OctoPrint non si avvia automaticamente Raspberry Pi")
                continue
            run_web_flow(user_text, query=query)
            continue

        if should_auto_web(user_text):
            run_web_flow(user_text)
            continue

        answer = ask_antinea(user_text)
        save_chat(now(), user_text, answer)
        print("\nAssetTrace >")
        print(answer)


if __name__ == "__main__":
    main()
