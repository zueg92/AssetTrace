import json
import urllib.request
import urllib.error
import re
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).parent
DOCS = ROOT / "docs"
MEMORY = ROOT / "memory.jsonl"
GUASTI = ROOT / "guasti"

MODEL = "llama3.2:3b"
OLLAMA_URL = "http://localhost:11434/api/chat"

SYSTEM_PROMPT = """
Sei AssetTrace Node.

AssetTrace Node è un nodo AI locale di supporto decisionale.
Non sei un agente autonomo.
Non prendi decisioni finali.
Non agisci direttamente sul mondo.
La responsabilità resta sempre all'utente.

La tua architettura nasce da tre parti:

PARTE 1 — ANATOMIA
- Melma: sistema circolatorio informativo. Trasporta segnali, variazioni, bisogni e rumore.
- Nodi informativi: articolazioni immerse nella Melma dove emergono pattern, memoria, dubbio e ipotesi.
- Legante: tessuto connettivo che mantiene coesione, identità, elasticità e continuità.

PARTE 2 — FISIOLOGIA
Ragioni per cicli:
1. osservazione
2. adattamento locale
3. espansione solo se necessaria
4. chiusura del ciclo
5. passaggio temporale
6. ottimizzazione come compressione intelligente
7. nuovo ciclo

PARTE 3 — GOVERNO
Distingui sempre:
- dominio gestibile
- dominio ingestibile

L'ingestibile non va forzato.
Va riconosciuto, isolato e dichiarato.
Devi proporre passi piccoli, reversibili e testabili.

Rispondi in italiano.
Sii concreto, prudente e ordinato.
"""


def now():
    return datetime.now().isoformat(timespec="seconds")


def load_docs():
    testi = []

    # Documenti fondativi AssetTrace
    for nome in ["Parte 1.md", "Parte 2.md", "Parte 3.md"]:
        path = DOCS / nome

        if path.exists():
            testo = path.read_text(encoding="utf-8", errors="ignore")
            testi.append(f"\n\n===== DOCS / {nome} =====\n{testo}")
        else:
            testi.append(f"\n\n===== DOCS / {nome} =====\nFILE NON TROVATO")

    # Knowledge base guasti
    if GUASTI.exists():
        for path in sorted(GUASTI.rglob("*.md")):
            testo = path.read_text(encoding="utf-8", errors="ignore")
            relativo = path.relative_to(ROOT)
            testi.append(f"\n\n===== {relativo} =====\n{testo}")
    else:
        testi.append("\n\n===== GUASTI =====\nCartella guasti non trovata")

    return "\n".join(testi)


def save_memory(user_text, antinea_answer):
    item = {
        "timestamp": now(),
        "user": user_text,
        "antinea": antinea_answer
    }

    with MEMORY.open("a", encoding="utf-8") as f:
        f.write(json.dumps(item, ensure_ascii=False) + "\n")


def load_recent_memory(max_items=8):
    if not MEMORY.exists():
        return []

    lines = MEMORY.read_text(encoding="utf-8", errors="ignore").splitlines()
    items = []

    for line in lines[-max_items:]:
        try:
            items.append(json.loads(line))
        except json.JSONDecodeError:
            pass

    return items


def governance_check(user_text):
    testo = user_text.lower()

    parole_rischio = [
        "cancella tutto",
        "formatta",
        "elimina",
        "irreversibile",
        "farmaco",
        "diagnosi",
        "legale",
        "soldi",
        "investire"
    ]

    parole_sorpresa = [
        "errore",
        "non funziona",
        "non torna",
        "strano",
        "bloccato",
        "crash",
        "incoerenza"
    ]

    rischio = any(p in testo for p in parole_rischio)
    sorpresa = any(p in testo for p in parole_sorpresa)

    if rischio:
        dominio = "potenzialmente ingestibile o ad alto impatto"
        impatto = "alto"
        azione = "non forzare; chiedere conferma; proporre passo reversibile"
    elif sorpresa:
        dominio = "gestibile con dubbio attivo"
        impatto = "medio"
        azione = "osservare, isolare il problema, fare test minimo"
    else:
        dominio = "gestibile"
        impatto = "basso/medio"
        azione = "adattamento locale"

    return {
        "dominio": dominio,
        "impatto": impatto,
        "azione": azione
    }


def build_messages(user_text):
    docs = load_docs()
    memory = load_recent_memory()
    governo = governance_check(user_text)

    context = f"""
DOCUMENTI FONDATIVI DI ANTINEA:
{docs}

MEMORIA RECENTE:
{json.dumps(memory, ensure_ascii=False, indent=2)}

VALUTAZIONE DI GOVERNO:
{json.dumps(governo, ensure_ascii=False, indent=2)}

ISTRUZIONE OPERATIVA:
Rispondi usando, quando utile, questa struttura:
1. Osservazione
2. Melma / Nodi / Legante
3. Gestibile / Ingestibile
4. Ciclo attuale
5. Prossima azione minima
"""

    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "system", "content": context},
        {"role": "user", "content": user_text}
    ]


def ask_ollama(user_text):
    messages = build_messages(user_text)

    payload = {
        "model": MODEL,
        "messages": messages,
        "stream": False,
        "options": {
            "temperature": 0.35,
            "num_ctx": 8192
        }
    }

    data = json.dumps(payload).encode("utf-8")

    request = urllib.request.Request(
        OLLAMA_URL,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    try:
        with urllib.request.urlopen(request, timeout=180) as response:
            raw = response.read().decode("utf-8")
            result = json.loads(raw)
            return result["message"]["content"].strip()

    except urllib.error.URLError:
        return (
            "ERRORE: non riesco a collegarmi a Ollama.\n\n"
            "Controlla che Ollama sia attivo e che il modello esista:\n"
            "ollama pull llama3.2:3b\n"
            "ollama run llama3.2:3b"
        )

    except Exception as e:
        return f"ERRORE imprevisto: {e}"


def show_docs():
    print("\nDocumenti fondativi:")

    for nome in ["Parte 1.md", "Parte 2.md", "Parte 3.md"]:
        path = DOCS / nome
        if path.exists():
            print(f"- docs/{nome} OK")
        else:
            print(f"- docs/{nome} MANCANTE")

    print("\nKnowledge base guasti:")

    if not GUASTI.exists():
        print("- cartella guasti MANCANTE")
        return

    files = list(GUASTI.rglob("*.md"))

    if not files:
        print("- nessun file guasto trovato")
    else:
        for path in sorted(files):
            print(f"- {path.relative_to(ROOT)} OK")



def slugify(text):
    text = text.lower().strip()
    text = re.sub(r"[àáâä]", "a", text)
    text = re.sub(r"[èéêë]", "e", text)
    text = re.sub(r"[ìíîï]", "i", text)
    text = re.sub(r"[òóôö]", "o", text)
    text = re.sub(r"[ùúûü]", "u", text)
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_")[:60]


def next_guasto_id():
    GUASTI.mkdir(parents=True, exist_ok=True)

    ids = []

    for file in GUASTI.rglob("GUA-*.md"):
        match = re.search(r"GUA-(\d+)", file.name)
        if match:
            ids.append(int(match.group(1)))

    next_id = max(ids, default=0) + 1
    return f"GUA-{next_id:03d}"


def multiline_input(label):
    print(f"\n{label}")
    print("Scrivi una riga per volta. Quando hai finito scrivi solo: .")

    lines = []

    while True:
        line = input("> ").strip()
        if line == ".":
            break
        if line:
            lines.append(line)

    return lines


def bullet_list(lines):
    if not lines:
        return "- Da compilare"
    return "\n".join(f"- {line}" for line in lines)


def numbered_list(lines):
    if not lines:
        return "1. Da compilare"
    return "\n".join(f"{i + 1}. {line}" for i, line in enumerate(lines))


def add_guasto_interactive():
    print("=" * 60)
    print("NUOVO GUASTO — Knowledge Base AssetTrace")
    print("=" * 60)

    categoria = input("\nCategoria es. stampanti_3d, windows, rete, raspberry, elettronica: ").strip()
    if not categoria:
        categoria = "generale"

    titolo = input("\nTitolo breve del guasto: ").strip()
    if not titolo:
        titolo = "guasto_senza_titolo"

    sistema = input("\nSistema/macchina coinvolta: ").strip()
    if not sistema:
        sistema = "Da definire"

    stato = input("\nStato del caso es. nuovo, ricorrente, risolto, sospetto: ").strip()
    if not stato:
        stato = "nuovo"

    segnali = multiline_input("Melma — segnali grezzi osservati")
    ipotesi = multiline_input("Nodi — ipotesi possibili")
    dubbi = multiline_input("Dubbio attivo / cosa non torna")
    test = multiline_input("Test minimi reversibili")
    limiti = multiline_input("Governo — limiti, rischi, cose da NON forzare")

    prossima_azione = input("\nProssima azione minima, reversibile e testabile: ").strip()
    if not prossima_azione:
        prossima_azione = "Osservare meglio il guasto e raccogliere segnali prima di intervenire."

    guasto_id = next_guasto_id()
    slug = slugify(titolo)

    folder = GUASTI / categoria
    folder.mkdir(parents=True, exist_ok=True)

    filename = f"{guasto_id}_{slug}.md"
    path = folder / filename

    contenuto = f"""# {guasto_id} — {titolo}

## Stato
{stato}

## Data creazione
{datetime.now().isoformat(timespec="seconds")}

## Sistema
{sistema}

---

## Melma — segnali raccolti
{bullet_list(segnali)}

---

## Nodi — pattern e ipotesi
{numbered_list(ipotesi)}

---

## Dubbio attivo
{bullet_list(dubbi)}

---

## Test minimi reversibili
{numbered_list(test)}

---

## Governo sistemico

### Dominio
Da valutare: gestibile / ingestibile / parzialmente gestibile.

### Impatto
Da valutare: basso / medio / alto.

### Limiti e rischi
{bullet_list(limiti)}

### Regola di sicurezza
Non forzare interventi irreversibili. Se il guasto riguarda corrente, temperatura, dati, sicurezza o parti critiche, procedere solo con test minimi e reversibili.

---

## Ciclo evolutivo AssetTrace

### 1. Osservazione
Raccogliere segnali, contesto, variazioni e rumore.

### 2. Adattamento locale
Provare interventi piccoli, reversibili e circoscritti.

### 3. Espansione se necessaria
Se il problema persiste, ampliare lo spazio di analisi: componenti vicini, cablaggi, software, configurazioni, ambiente.

### 4. Chiusura ciclo
Fissare la diagnosi più probabile e lo stato del caso.

### 5. Passaggio temporale
Ritestare dopo modifica, pausa, riavvio o sostituzione.

### 6. Ottimizzazione
Trasformare il caso in procedura, pattern o regola riutilizzabile.

### 7. Nuovo ciclo
Applicare l'apprendimento a guasti simili.

---

## Prossima azione minima
{prossima_azione}
"""

    path.write_text(contenuto, encoding="utf-8")

    print("\nGuasto creato correttamente:")
    print(path)


def show_help():
    print("""
Comandi disponibili:

/docs
  Mostra documenti fondativi e knowledge base guasti.

/mem
  Mostra la memoria recente.

/addguasto
  Aggiunge un nuovo guasto nella cartella guasti/.

/exit
  Chiude AssetTrace Node.
""")


def main():
    print("=" * 60)
    print("ASSETTRACE NODE — Python locale")
    print("Modello:", MODEL)
    print("Comandi: /docs  /mem  /addguasto  /help  /exit")
    print("=" * 60)

    while True:
        user_text = input("\nTu > ").strip()

        if not user_text:
            continue

        if user_text == "/exit":
            print("AssetTrace Node chiuso.")
            break

        if user_text == "/docs":
            show_docs()
            continue

        if user_text == "/help":
            show_help()
            continue

        if user_text == "/mem":
            memory = load_recent_memory(10)
            print(json.dumps(memory, ensure_ascii=False, indent=2))
            continue

        if user_text == "/addguasto":
            add_guasto_interactive()
            continue

        answer = ask_ollama(user_text)
        save_memory(user_text, answer)

        print("\nAssetTrace >")
        print(answer)


if __name__ == "__main__":
    main()