from pathlib import Path
from datetime import datetime
import re

ROOT = Path(__file__).parent
GUASTI = ROOT / "guasti"


def slugify(text):
    text = text.lower().strip()
    text = re.sub(r"[àáâä]", "a", text)
    text = re.sub(r"[èéêë]", "e", text)
    text = re.sub(r"[ìíîï]", "i", text)
    text = re.sub(r"[òóôö]", "o", text)
    text = re.sub(r"[ùúûü]", "u", text)
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_")[:60]


def next_guasto_id():
    GUASTI.mkdir(exist_ok=True)

    ids = []

    for file in GUASTI.rglob("GUA-*.md"):
        match = re.search(r"GUA-(\d+)", file.name)
        if match:
            ids.append(int(match.group(1)))

    next_id = max(ids, default=0) + 1
    return f"GUA-{next_id:03d}"


def multiline_input(label):
    print(f"\n{label}")
    print("Scrivi una riga per volta. Quando hai finito scrivi solo: .")

    lines = []

    while True:
        line = input("> ").strip()
        if line == ".":
            break
        if line:
            lines.append(line)

    return lines


def bullet_list(lines):
    if not lines:
        return "- Da compilare"
    return "\n".join(f"- {line}" for line in lines)


def numbered_list(lines):
    if not lines:
        return "1. Da compilare"
    return "\n".join(f"{i + 1}. {line}" for i, line in enumerate(lines))


def main():
    print("=" * 60)
    print("AGGIUNGI GUASTO — AssetTrace Node")
    print("=" * 60)

    categoria = input("\nCategoria guasto es. stampanti_3d, windows, rete, raspberry, elettronica: ").strip()
    if not categoria:
        categoria = "generale"

    titolo = input("\nTitolo breve del guasto: ").strip()
    if not titolo:
        titolo = "guasto_senza_titolo"

    sistema = input("\nSistema/macchina coinvolta: ").strip()
    if not sistema:
        sistema = "Da definire"

    stato = input("\nStato del caso es. nuovo, ricorrente, risolto, sospetto: ").strip()
    if not stato:
        stato = "nuovo"

    segnali = multiline_input("Melma — segnali grezzi osservati")
    ipotesi = multiline_input("Nodi — ipotesi possibili")
    dubbi = multiline_input("Dubbio attivo / cosa non torna")
    test = multiline_input("Test minimi reversibili")
    limiti = multiline_input("Governo — limiti, rischi, cose da NON forzare")

    prossima_azione = input("\nProssima azione minima, reversibile e testabile: ").strip()
    if not prossima_azione:
        prossima_azione = "Osservare meglio il guasto e raccogliere segnali prima di intervenire."

    guasto_id = next_guasto_id()
    slug = slugify(titolo)

    folder = GUASTI / categoria
    folder.mkdir(parents=True, exist_ok=True)

    filename = f"{guasto_id}_{slug}.md"
    path = folder / filename

    contenuto = f"""# {guasto_id} — {titolo}

## Stato
{stato}

## Data creazione
{datetime.now().isoformat(timespec="seconds")}

## Sistema
{sistema}

---

## Melma — segnali raccolti
{bullet_list(segnali)}

---

## Nodi — pattern e ipotesi
{numbered_list(ipotesi)}

---

## Dubbio attivo
{bullet_list(dubbi)}

---

## Test minimi reversibili
{numbered_list(test)}

---

## Governo sistemico

### Dominio
Da valutare: gestibile / ingestibile / parzialmente gestibile.

### Impatto
Da valutare: basso / medio / alto.

### Limiti e rischi
{bullet_list(limiti)}

### Regola di sicurezza
Non forzare interventi irreversibili. Se il guasto riguarda corrente, temperatura, dati, sicurezza o parti critiche, procedere solo con test minimi e reversibili.

---

## Ciclo evolutivo AssetTrace

### 1. Osservazione
Raccogliere segnali, contesto, variazioni e rumore.

### 2. Adattamento locale
Provare interventi piccoli, reversibili e circoscritti.

### 3. Espansione se necessaria
Se il problema persiste, ampliare lo spazio di analisi: componenti vicini, cablaggi, software, configurazioni, ambiente.

### 4. Chiusura ciclo
Fissare la diagnosi più probabile e lo stato del caso.

### 5. Passaggio temporale
Ritestare dopo modifica, pausa, riavvio o sostituzione.

### 6. Ottimizzazione
Trasformare il caso in procedura, pattern o regola riutilizzabile.

### 7. Nuovo ciclo
Applicare l'apprendimento a guasti simili.

---

## Prossima azione minima
{prossima_azione}
"""

    path.write_text(contenuto, encoding="utf-8")

    print("\nGuasto creato correttamente:")
    print(path)


if __name__ == "__main__":
    main()