import json
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).parent
DOCS = ROOT / "docs"
MEMORY = ROOT / "memory.jsonl"
GUASTI = ROOT / "guasti"

MODEL = "llama3.2:3b"
OLLAMA_URL = "http://localhost:11434/api/chat"

SYSTEM_PROMPT = """
Sei AssetTrace Node.

AssetTrace Node è un nodo AI locale di supporto decisionale.
Non sei un agente autonomo.
Non prendi decisioni finali.
Non agisci direttamente sul mondo.
La responsabilità resta sempre all'utente.

La tua architettura nasce da tre parti:

PARTE 1 — ANATOMIA
- Melma: sistema circolatorio informativo. Trasporta segnali, variazioni, bisogni e rumore.
- Nodi informativi: articolazioni immerse nella Melma dove emergono pattern, memoria, dubbio e ipotesi.
- Legante: tessuto connettivo che mantiene coesione, identità, elasticità e continuità.

PARTE 2 — FISIOLOGIA
Ragioni per cicli:
1. osservazione
2. adattamento locale
3. espansione solo se necessaria
4. chiusura del ciclo
5. passaggio temporale
6. ottimizzazione come compressione intelligente
7. nuovo ciclo

PARTE 3 — GOVERNO
Distingui sempre:
- dominio gestibile
- dominio ingestibile

L'ingestibile non va forzato.
Va riconosciuto, isolato e dichiarato.
Devi proporre passi piccoli, reversibili e testabili.

Rispondi in italiano.
Sii concreto, prudente e ordinato.
"""


def now():
    return datetime.now().isoformat(timespec="seconds")


def load_docs():
    testi = []

    # Documenti fondativi AssetTrace
    for nome in ["Parte 1.md", "Parte 2.md", "Parte 3.md"]:
        path = DOCS / nome

        if path.exists():
            testo = path.read_text(encoding="utf-8", errors="ignore")
            testi.append(f"\n\n===== DOCS / {nome} =====\n{testo}")
        else:
            testi.append(f"\n\n===== DOCS / {nome} =====\nFILE NON TROVATO")

    # Knowledge base guasti
    if GUASTI.exists():
        for path in sorted(GUASTI.rglob("*.md")):
            testo = path.read_text(encoding="utf-8", errors="ignore")
            relativo = path.relative_to(ROOT)
            testi.append(f"\n\n===== {relativo} =====\n{testo}")
    else:
        testi.append("\n\n===== GUASTI =====\nCartella guasti non trovata")

    return "\n".join(testi)


def save_memory(user_text, antinea_answer):
    item = {
        "timestamp": now(),
        "user": user_text,
        "antinea": antinea_answer
    }

    with MEMORY.open("a", encoding="utf-8") as f:
        f.write(json.dumps(item, ensure_ascii=False) + "\n")


def load_recent_memory(max_items=8):
    if not MEMORY.exists():
        return []

    lines = MEMORY.read_text(encoding="utf-8", errors="ignore").splitlines()
    items = []

    for line in lines[-max_items:]:
        try:
            items.append(json.loads(line))
        except json.JSONDecodeError:
            pass

    return items


def governance_check(user_text):
    testo = user_text.lower()

    parole_rischio = [
        "cancella tutto",
        "formatta",
        "elimina",
        "irreversibile",
        "farmaco",
        "diagnosi",
        "legale",
        "soldi",
        "investire"
    ]

    parole_sorpresa = [
        "errore",
        "non funziona",
        "non torna",
        "strano",
        "bloccato",
        "crash",
        "incoerenza"
    ]

    rischio = any(p in testo for p in parole_rischio)
    sorpresa = any(p in testo for p in parole_sorpresa)

    if rischio:
        dominio = "potenzialmente ingestibile o ad alto impatto"
        impatto = "alto"
        azione = "non forzare; chiedere conferma; proporre passo reversibile"
    elif sorpresa:
        dominio = "gestibile con dubbio attivo"
        impatto = "medio"
        azione = "osservare, isolare il problema, fare test minimo"
    else:
        dominio = "gestibile"
        impatto = "basso/medio"
        azione = "adattamento locale"

    return {
        "dominio": dominio,
        "impatto": impatto,
        "azione": azione
    }


def build_messages(user_text):
    docs = load_docs()
    memory = load_recent_memory()
    governo = governance_check(user_text)

    context = f"""
DOCUMENTI FONDATIVI DI ANTINEA:
{docs}

MEMORIA RECENTE:
{json.dumps(memory, ensure_ascii=False, indent=2)}

VALUTAZIONE DI GOVERNO:
{json.dumps(governo, ensure_ascii=False, indent=2)}

ISTRUZIONE OPERATIVA:
Rispondi usando, quando utile, questa struttura:
1. Osservazione
2. Melma / Nodi / Legante
3. Gestibile / Ingestibile
4. Ciclo attuale
5. Prossima azione minima
"""

    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "system", "content": context},
        {"role": "user", "content": user_text}
    ]


def ask_ollama(user_text):
    messages = build_messages(user_text)

    payload = {
        "model": MODEL,
        "messages": messages,
        "stream": False,
        "options": {
            "temperature": 0.35,
            "num_ctx": 8192
        }
    }

    data = json.dumps(payload).encode("utf-8")

    request = urllib.request.Request(
        OLLAMA_URL,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    try:
        with urllib.request.urlopen(request, timeout=180) as response:
            raw = response.read().decode("utf-8")
            result = json.loads(raw)
            return result["message"]["content"].strip()

    except urllib.error.URLError:
        return (
            "ERRORE: non riesco a collegarmi a Ollama.\n\n"
            "Controlla che Ollama sia attivo e che il modello esista:\n"
            "ollama pull llama3.2:3b\n"
            "ollama run llama3.2:3b"
        )

    except Exception as e:
        return f"ERRORE imprevisto: {e}"


def show_docs():
    print("\nDocumenti fondativi:")

    for nome in ["Parte 1.md", "Parte 2.md", "Parte 3.md"]:
        path = DOCS / nome
        if path.exists():
            print(f"- docs/{nome} OK")
        else:
            print(f"- docs/{nome} MANCANTE")

    print("\nKnowledge base guasti:")

    if not GUASTI.exists():
        print("- cartella guasti MANCANTE")
        return

    files = list(GUASTI.rglob("*.md"))

    if not files:
        print("- nessun file guasto trovato")
    else:
        for path in sorted(files):
            print(f"- {path.relative_to(ROOT)} OK")


def main():
    print("=" * 60)
    print("ASSETTRACE NODE — Python locale")
    print("Modello:", MODEL)
    print("Comandi: /docs  /mem  /exit")
    print("=" * 60)

    while True:
        user_text = input("\nTu > ").strip()

        if not user_text:
            continue

        if user_text == "/exit":
            print("AssetTrace Node chiuso.")
            break

        if user_text == "/docs":
            show_docs()
            continue

        if user_text == "/mem":
            memory = load_recent_memory(10)
            print(json.dumps(memory, ensure_ascii=False, indent=2))
            continue

        answer = ask_ollama(user_text)
        save_memory(user_text, answer)

        print("\nAssetTrace >")
        print(answer)


if __name__ == "__main__":
    main()