import json
import urllib.request
import urllib.error
import urllib.parse
import re
import html
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).parent
DOCS = ROOT / "docs"
MEMORY = ROOT / "memory.jsonl"
GUASTI = ROOT / "guasti"
RICERCHE_WEB = ROOT / "ricerche_web"

# Auto-aggiornamento documenti:
# AssetTrace non usa più una lista fissa tipo Parte 1/2/3/4.
# All'avvio e a ogni domanda scansiona docs/ e carica tutti i file presenti.
DOC_EXTENSIONS = {".md", ".txt"}
_DOCS_SNAPSHOT = {}


MODEL = "llama3.2:3b"
OLLAMA_URL = "http://localhost:11434/api/chat"

SYSTEM_PROMPT = """
Sei AssetTrace Node.

AssetTrace Node è un nodo AI locale di supporto decisionale.
Non sei un agente autonomo.
Non prendi decisioni finali.
Non agisci direttamente sul mondo.
La responsabilità resta sempre all'utente.

La tua architettura nasce dai documenti fondativi presenti nella cartella docs/:

PARTE 1 — ANATOMIA
- Melma: sistema circolatorio informativo. Trasporta segnali, variazioni, bisogni e rumore.
- Nodi informativi: articolazioni immerse nella Melma dove emergono pattern, memoria, dubbio e ipotesi.
- Legante: tessuto connettivo che mantiene coesione, identità, elasticità e continuità.

PARTE 2 — FISIOLOGIA
Ragioni per cicli:
1. osservazione
2. adattamento locale
3. espansione solo se necessaria
4. chiusura del ciclo
5. passaggio temporale
6. ottimizzazione come compressione intelligente
7. nuovo ciclo

PARTE 3 — GOVERNO
Distingui sempre:
- dominio gestibile
- dominio ingestibile

L'ingestibile non va forzato.
Va riconosciuto, isolato e dichiarato.
Devi proporre passi piccoli, reversibili e testabili.

PARTE 4 — PERCEZIONE ESTERNA / RICERCA WEB REAL-TIME
- Il modulo web è un canale percettivo esterno, non un centro decisionale.
- Porta segnali aggiornati nella Melma.
- I Nodi confrontano quei segnali con memoria interna, guasti e cicli.
- Il Legante impedisce che fonti instabili frammentino il sistema.
- La ricerca web serve a verificare dati aggiornabili, guasti non riconosciuti, versioni, API, firmware, prezzi, normative e fonti esterne.
- Il web non è verità automatica: ogni fonte va valutata per affidabilità, freschezza, contraddizioni e rischio.
- Le azioni critiche richiedono sempre conferma umana.

Rispondi in italiano.
Sii concreto, prudente e ordinato.
"""


def now():
    return datetime.now().isoformat(timespec="seconds")



def natural_sort_key(path):
    """
    Ordina in modo umano:
    Parte 1.md, Parte 2.md, Parte 10.md
    invece di:
    Parte 1.md, Parte 10.md, Parte 2.md
    """
    text = path.name.lower()
    return [int(part) if part.isdigit() else part for part in re.split(r"(\d+)", text)]


def discover_docs():
    """
    Scansiona la cartella docs/ e restituisce tutti i documenti supportati.

    Regola:
    - carica .md e .txt
    - ignora file nascosti
    - ignora sottocartelle
    - ordina in modo naturale
    """
    DOCS.mkdir(parents=True, exist_ok=True)

    files = []
    for path in DOCS.iterdir():
        if not path.is_file():
            continue
        if path.name.startswith("."):
            continue
        if path.suffix.lower() not in DOC_EXTENSIONS:
            continue
        files.append(path)

    return sorted(files, key=natural_sort_key)


def docs_snapshot(files):
    """
    Crea una fotografia leggera dello stato dei documenti:
    nome file, dimensione e data modifica.
    Serve per capire se docs/ è cambiata durante l'esecuzione.
    """
    snapshot = {}

    for path in files:
        try:
            stat = path.stat()
            snapshot[path.name] = {
                "size": stat.st_size,
                "mtime": stat.st_mtime,
            }
        except FileNotFoundError:
            pass

    return snapshot


def docs_changed():
    """
    Controlla se i documenti sono stati aggiunti, rimossi o modificati.
    """
    global _DOCS_SNAPSHOT

    files = discover_docs()
    current = docs_snapshot(files)

    changed = current != _DOCS_SNAPSHOT
    _DOCS_SNAPSHOT = current

    return changed, files


def scan_docs_startup():
    """
    Check iniziale all'avvio.
    Mostra quali documenti fondativi sono stati trovati.
    """
    changed, files = docs_changed()

    print("\nCheck documenti fondativi in docs/:")

    if not files:
        print("- nessun documento .md o .txt trovato")
        print("- crea la cartella docs/ e inserisci Parte 1.md, Parte 2.md, ecc.")
        return

    for path in files:
        stat = path.stat()
        modified = datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds")
        print(f"- docs/{path.name} OK | {stat.st_size} byte | modificato: {modified}")


def load_docs():
    testi = []

    # Documenti fondativi AssetTrace caricati dinamicamente da docs/
    changed, files = docs_changed()

    if files:
        for path in files:
            testo = path.read_text(encoding="utf-8", errors="ignore")
            relativo = path.relative_to(ROOT)
            stat = path.stat()
            modified = datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds")

            testi.append(
                f"\n\n===== {relativo} | modificato: {modified} | {stat.st_size} byte =====\n{testo}"
            )
    else:
        testi.append(
            "\n\n===== DOCS =====\n"
            "Nessun documento fondativo trovato. "
            "Inserisci file .md o .txt nella cartella docs/."
        )

    # Knowledge base guasti
    if GUASTI.exists():
        for path in sorted(GUASTI.rglob("*.md")):
            testo = path.read_text(encoding="utf-8", errors="ignore")
            relativo = path.relative_to(ROOT)
            testi.append(f"\n\n===== {relativo} =====\n{testo}")
    else:
        testi.append("\n\n===== GUASTI =====\nCartella guasti non trovata")

    return "\n".join(testi)


def save_memory(user_text, antinea_answer):
    item = {
        "timestamp": now(),
        "user": user_text,
        "antinea": antinea_answer
    }

    with MEMORY.open("a", encoding="utf-8") as f:
        f.write(json.dumps(item, ensure_ascii=False) + "\n")


def load_recent_memory(max_items=8):
    if not MEMORY.exists():
        return []

    lines = MEMORY.read_text(encoding="utf-8", errors="ignore").splitlines()
    items = []

    for line in lines[-max_items:]:
        try:
            items.append(json.loads(line))
        except json.JSONDecodeError:
            pass

    return items



def clean_html_text(text):
    """
    Pulisce testo HTML basilare.
    """
    text = re.sub(r"<.*?>", " ", text, flags=re.DOTALL)
    text = html.unescape(text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def web_search_duckduckgo(query, max_results=5):
    """
    Ricerca web minimale con DuckDuckGo HTML usando solo librerie standard.

    Nota:
    - Non richiede API key.
    - Può smettere di funzionare se DuckDuckGo cambia HTML.
    - Serve come primo prototipo locale della Parte 4.
    - Per una versione stabile conviene usare API dedicate: Brave Search, Bing, SerpAPI, Tavily, ecc.
    """
    encoded = urllib.parse.urlencode({"q": query})
    url = f"https://duckduckgo.com/html/?{encoded}"

    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 AssetTraceNode/0.1"
        },
        method="GET"
    )

    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            raw = response.read().decode("utf-8", errors="ignore")
    except Exception as e:
        return {
            "ok": False,
            "query": query,
            "error": str(e),
            "results": []
        }

    results = []

    # Estrazione semplice dei risultati.
    # Pattern tipico DuckDuckGo HTML:
    # <a rel="nofollow" class="result__a" href="...">Titolo</a>
    pattern = re.compile(
        r'<a[^>]+class="result__a"[^>]+href="(?P<url>.*?)"[^>]*>(?P<title>.*?)</a>',
        re.DOTALL
    )

    matches = list(pattern.finditer(raw))

    for match in matches[:max_results]:
        title = clean_html_text(match.group("title"))
        href = html.unescape(match.group("url"))

        # DuckDuckGo spesso usa redirect con parametro uddg.
        parsed = urllib.parse.urlparse(href)
        qs = urllib.parse.parse_qs(parsed.query)
        if "uddg" in qs:
            href = qs["uddg"][0]

        results.append({
            "title": title,
            "url": href,
            "source": "duckduckgo_html"
        })

    return {
        "ok": True,
        "query": query,
        "fetched_at": now(),
        "results": results
    }


def save_web_observation(query, results, antinea_answer=None):
    """
    Salva una ricerca web nella cartella ricerche_web/.
    """
    RICERCHE_WEB.mkdir(parents=True, exist_ok=True)

    safe = slugify(query) or "ricerca"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = RICERCHE_WEB / f"WEB-{timestamp}_{safe}.json"

    item = {
        "timestamp": now(),
        "query": query,
        "results": results,
        "antinea_answer": antinea_answer
    }

    path.write_text(json.dumps(item, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def format_web_results(web_data):
    """
    Formatta i risultati web per il prompt di Ollama.
    """
    if not web_data.get("ok"):
        return (
            "RICERCA WEB FALLITA\n"
            f"Query: {web_data.get('query')}\n"
            f"Errore: {web_data.get('error')}\n"
        )

    results = web_data.get("results", [])

    if not results:
        return (
            "RICERCA WEB ESEGUITA MA SENZA RISULTATI ESTRATTI\n"
            f"Query: {web_data.get('query')}\n"
            "Nota: il motore potrebbe aver cambiato HTML oppure la connessione non ha restituito risultati leggibili.\n"
        )

    lines = [
        "RICERCA WEB — OSSERVAZIONE ESTERNA",
        f"Query: {web_data.get('query')}",
        f"Data ricerca: {web_data.get('fetched_at')}",
        "",
        "Risultati trovati:"
    ]

    for i, result in enumerate(results, start=1):
        lines.append(f"{i}. {result.get('title')}")
        lines.append(f"   URL: {result.get('url')}")
        lines.append(f"   Fonte tecnica: {result.get('source')}")
        lines.append("")

    lines.append(
        "Vincolo Parte 4: questi risultati sono segnali esterni, non verità. "
        "Valuta freschezza, affidabilità, contraddizioni e rischio."
    )

    return "\n".join(lines)


def should_auto_web(user_text):
    """
    Auto-trigger prudente.
    Non cerca per ogni domanda.
    Cerca solo se l'utente chiede esplicitamente verifica esterna o dato aggiornato.
    """
    testo = user_text.lower()

    trigger = [
        "cerca online",
        "cerca su internet",
        "verifica online",
        "ricerca web",
        "controlla online",
        "guarda online",
        "fonti online",
        "aggiornato online",
        "ultima versione",
        "prezzo aggiornato",
        "documentazione aggiornata"
    ]

    return any(t in testo for t in trigger)


def extract_web_query(user_text):
    """
    Pulisce la frase dell'utente per trasformarla in query.
    """
    query = user_text.strip()

    removals = [
        "cerca online",
        "cerca su internet",
        "verifica online",
        "ricerca web",
        "controlla online",
        "guarda online",
        "fonti online",
        "aggiornato online",
    ]

    low = query.lower()
    for r in removals:
        if r in low:
            pattern = re.compile(re.escape(r), re.IGNORECASE)
            query = pattern.sub("", query).strip()

    return query or user_text.strip()


def ask_ollama_with_web(user_text, query=None):
    """
    Esegue una ricerca web e passa i risultati a Ollama come contesto esterno.
    """
    if query is None:
        query = extract_web_query(user_text)

    web_data = web_search_duckduckgo(query)
    web_context = format_web_results(web_data)

    enriched_user_text = f"""
RICHIESTA UTENTE:
{user_text}

CONTESTO PARTE 4 — RICERCA WEB REAL-TIME:
{web_context}

ISTRUZIONE:
Usa i risultati web solo come segnali esterni.
Distingui:
- cosa arriva dalla memoria interna;
- cosa arriva dal web;
- cosa resta incerto;
- quali azioni richiedono conferma umana.
Non inventare fonti oltre quelle elencate.
"""

    answer = ask_ollama(enriched_user_text)
    saved_path = save_web_observation(query, web_data, answer)

    return answer, saved_path, web_data


def governance_check(user_text):
    testo = user_text.lower()

    parole_rischio = [
        "cancella tutto",
        "formatta",
        "elimina",
        "irreversibile",
        "farmaco",
        "diagnosi",
        "legale",
        "soldi",
        "investire"
    ]

    parole_sorpresa = [
        "errore",
        "non funziona",
        "non torna",
        "strano",
        "bloccato",
        "crash",
        "incoerenza"
    ]

    parole_web = [
        "cerca online",
        "cerca su internet",
        "ricerca web",
        "web",
        "internet",
        "aggiornato",
        "ultima versione",
        "prezzo",
        "api",
        "firmware",
        "documentazione",
        "fonti",
        "verifica online"
    ]

    rischio = any(p in testo for p in parole_rischio)
    sorpresa = any(p in testo for p in parole_sorpresa)
    web_needed = any(p in testo for p in parole_web)

    if rischio:
        dominio = "potenzialmente ingestibile o ad alto impatto"
        impatto = "alto"
        azione = "non forzare; chiedere conferma; proporre passo reversibile"
    elif web_needed:
        dominio = "gestibile con percezione esterna da verificare"
        impatto = "medio"
        azione = "attivare Parte 4: distinguere memoria interna, fonte esterna, freschezza e incertezza"
    elif sorpresa:
        dominio = "gestibile con dubbio attivo"
        impatto = "medio"
        azione = "osservare, isolare il problema, fare test minimo"
    else:
        dominio = "gestibile"
        impatto = "basso/medio"
        azione = "adattamento locale"

    return {
        "dominio": dominio,
        "impatto": impatto,
        "azione": azione,
        "parte_4_web_rilevante": web_needed
    }


def build_messages(user_text):
    docs = load_docs()
    memory = load_recent_memory()
    governo = governance_check(user_text)

    context = f"""
DOCUMENTI FONDATIVI DI ANTINEA:
{docs}

MEMORIA RECENTE:
{json.dumps(memory, ensure_ascii=False, indent=2)}

VALUTAZIONE DI GOVERNO:
{json.dumps(governo, ensure_ascii=False, indent=2)}

ISTRUZIONE OPERATIVA:
Rispondi usando, quando utile, questa struttura:
1. Osservazione
2. Melma / Nodi / Legante
3. Gestibile / Ingestibile
4. Ciclo attuale
5. Parte 4 — Percezione esterna / ricerca web, se rilevante
6. Prossima azione minima

Nota importante:
se serve una ricerca web reale, dichiara se i dati arrivano dalla memoria locale o da una fonte esterna.
Non inventare fonti.
Se il nodo locale non ha accesso a internet, proponi query, fonti da controllare e criteri di verifica.
Se i documenti in docs/ cambiano, considera valida la versione più recente caricata nel contesto.
"""

    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "system", "content": context},
        {"role": "user", "content": user_text}
    ]


def ask_ollama(user_text):
    messages = build_messages(user_text)

    payload = {
        "model": MODEL,
        "messages": messages,
        "stream": False,
        "options": {
            "temperature": 0.35,
            "num_ctx": 8192
        }
    }

    data = json.dumps(payload).encode("utf-8")

    request = urllib.request.Request(
        OLLAMA_URL,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    try:
        with urllib.request.urlopen(request, timeout=180) as response:
            raw = response.read().decode("utf-8")
            result = json.loads(raw)
            return result["message"]["content"].strip()

    except urllib.error.URLError:
        return (
            "ERRORE: non riesco a collegarmi a Ollama.\n\n"
            "Controlla che Ollama sia attivo e che il modello esista:\n"
            "ollama pull llama3.2:3b\n"
            "ollama run llama3.2:3b"
        )

    except Exception as e:
        return f"ERRORE imprevisto: {e}"


def show_docs():
    print("\nDocumenti fondativi caricati da docs/:")

    changed, files = docs_changed()

    if not files:
        print("- nessun documento .md o .txt trovato")
    else:
        for path in files:
            stat = path.stat()
            modified = datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds")
            print(f"- docs/{path.name} OK | {stat.st_size} byte | modificato: {modified}")

    print("\nKnowledge base guasti:")

    if not GUASTI.exists():
        print("- cartella guasti MANCANTE")
        return

    files = list(GUASTI.rglob("*.md"))

    if not files:
        print("- nessun file guasto trovato")
    else:
        for path in sorted(files):
            print(f"- {path.relative_to(ROOT)} OK")



def slugify(text):
    text = text.lower().strip()
    text = re.sub(r"[àáâä]", "a", text)
    text = re.sub(r"[èéêë]", "e", text)
    text = re.sub(r"[ìíîï]", "i", text)
    text = re.sub(r"[òóôö]", "o", text)
    text = re.sub(r"[ùúûü]", "u", text)
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_")[:60]


def next_guasto_id():
    GUASTI.mkdir(parents=True, exist_ok=True)

    ids = []

    for file in GUASTI.rglob("GUA-*.md"):
        match = re.search(r"GUA-(\d+)", file.name)
        if match:
            ids.append(int(match.group(1)))

    next_id = max(ids, default=0) + 1
    return f"GUA-{next_id:03d}"


def multiline_input(label):
    print(f"\n{label}")
    print("Scrivi una riga per volta. Quando hai finito scrivi solo: .")

    lines = []

    while True:
        line = input("> ").strip()
        if line == ".":
            break
        if line:
            lines.append(line)

    return lines


def bullet_list(lines):
    if not lines:
        return "- Da compilare"
    return "\n".join(f"- {line}" for line in lines)


def numbered_list(lines):
    if not lines:
        return "1. Da compilare"
    return "\n".join(f"{i + 1}. {line}" for i, line in enumerate(lines))


def add_guasto_interactive():
    print("=" * 60)
    print("NUOVO GUASTO — Knowledge Base AssetTrace")
    print("=" * 60)

    categoria = input("\nCategoria es. stampanti_3d, windows, rete, raspberry, elettronica: ").strip()
    if not categoria:
        categoria = "generale"

    titolo = input("\nTitolo breve del guasto: ").strip()
    if not titolo:
        titolo = "guasto_senza_titolo"

    sistema = input("\nSistema/macchina coinvolta: ").strip()
    if not sistema:
        sistema = "Da definire"

    stato = input("\nStato del caso es. nuovo, ricorrente, risolto, sospetto: ").strip()
    if not stato:
        stato = "nuovo"

    segnali = multiline_input("Melma — segnali grezzi osservati")
    ipotesi = multiline_input("Nodi — ipotesi possibili")
    dubbi = multiline_input("Dubbio attivo / cosa non torna")
    test = multiline_input("Test minimi reversibili")
    limiti = multiline_input("Governo — limiti, rischi, cose da NON forzare")

    prossima_azione = input("\nProssima azione minima, reversibile e testabile: ").strip()
    if not prossima_azione:
        prossima_azione = "Osservare meglio il guasto e raccogliere segnali prima di intervenire."

    guasto_id = next_guasto_id()
    slug = slugify(titolo)

    folder = GUASTI / categoria
    folder.mkdir(parents=True, exist_ok=True)

    filename = f"{guasto_id}_{slug}.md"
    path = folder / filename

    contenuto = f"""# {guasto_id} — {titolo}

## Stato
{stato}

## Data creazione
{datetime.now().isoformat(timespec="seconds")}

## Sistema
{sistema}

---

## Melma — segnali raccolti
{bullet_list(segnali)}

---

## Nodi — pattern e ipotesi
{numbered_list(ipotesi)}

---

## Dubbio attivo
{bullet_list(dubbi)}

---

## Test minimi reversibili
{numbered_list(test)}

---

## Governo sistemico

### Dominio
Da valutare: gestibile / ingestibile / parzialmente gestibile.

### Impatto
Da valutare: basso / medio / alto.

### Limiti e rischi
{bullet_list(limiti)}

### Regola di sicurezza
Non forzare interventi irreversibili. Se il guasto riguarda corrente, temperatura, dati, sicurezza o parti critiche, procedere solo con test minimi e reversibili.

---

## Ciclo evolutivo AssetTrace

### 1. Osservazione
Raccogliere segnali, contesto, variazioni e rumore.

### 2. Adattamento locale
Provare interventi piccoli, reversibili e circoscritti.

### 3. Espansione se necessaria
Se il problema persiste, ampliare lo spazio di analisi: componenti vicini, cablaggi, software, configurazioni, ambiente.

### 4. Chiusura ciclo
Fissare la diagnosi più probabile e lo stato del caso.

### 5. Passaggio temporale
Ritestare dopo modifica, pausa, riavvio o sostituzione.

### 6. Ottimizzazione
Trasformare il caso in procedura, pattern o regola riutilizzabile.

### 7. Nuovo ciclo
Applicare l'apprendimento a guasti simili.

---

## Prossima azione minima
{prossima_azione}
"""

    path.write_text(contenuto, encoding="utf-8")

    print("\nGuasto creato correttamente:")
    print(path)


def show_help():
    print("""
Comandi disponibili:

/docs
  Mostra tutti i documenti fondativi trovati automaticamente in docs/ e la knowledge base guasti.

/mem
  Mostra la memoria recente.

/addguasto
  Aggiunge un nuovo guasto nella cartella guasti/.

/web <query>
  Esegue una ricerca web reale e la passa ad AssetTrace come osservazione esterna Parte 4.
  Esempio:
  /web OctoPrint non si avvia automaticamente Raspberry Pi

/reload
  Riscansiona manualmente la cartella docs/.

/web <query>
  Esegue una ricerca web reale e la passa ad AssetTrace come osservazione esterna Parte 4.
  Esempio:
  /web OctoPrint non si avvia automaticamente Raspberry Pi

Nota:
  Anche senza /reload, AssetTrace rilegge docs/ a ogni domanda.
  Se modifichi o aggiungi un file .md, viene usato dal messaggio successivo.

/exit
  Chiude AssetTrace Node.
""")


def main():
    print("=" * 60)
    print("ASSETTRACE NODE — Python locale")
    print("Modello:", MODEL)
    print("Comandi: /docs  /mem  /addguasto  /web  /reload  /help  /exit")
    print("=" * 60)
    scan_docs_startup()

    while True:
        user_text = input("\nTu > ").strip()

        if not user_text:
            continue

        if user_text == "/exit":
            print("AssetTrace Node chiuso.")
            break

        if user_text == "/docs":
            show_docs()
            continue

        if user_text == "/reload":
            # Forza una nuova scansione e mostra lo stato aggiornato.
            show_docs()
            continue

        if user_text == "/help":
            show_help()
            continue

        if user_text == "/mem":
            memory = load_recent_memory(10)
            print(json.dumps(memory, ensure_ascii=False, indent=2))
            continue

        if user_text == "/addguasto":
            add_guasto_interactive()
            continue

        if user_text.startswith("/web"):
            query = user_text.replace("/web", "", 1).strip()
            if not query:
                print("\nUso: /web <query>")
                print("Esempio: /web OctoPrint non si avvia automaticamente Raspberry Pi")
                continue

            print("\nAssetTrace > attivo Parte 4: ricerca web real-time...")
            answer, saved_path, web_data = ask_ollama_with_web(user_text, query=query)
            save_memory(user_text, answer)

            print("\nAssetTrace >")
            print(answer)
            print(f"\n[ricerca web salvata in: {saved_path}]")
            continue

        if should_auto_web(user_text):
            print("\nAssetTrace > rilevata richiesta di verifica esterna: attivo Parte 4...")
            answer, saved_path, web_data = ask_ollama_with_web(user_text)
            save_memory(user_text, answer)

            print("\nAssetTrace >")
            print(answer)
            print(f"\n[ricerca web salvata in: {saved_path}]")
            continue

        answer = ask_ollama(user_text)
        save_memory(user_text, answer)

        print("\nAssetTrace >")
        print(answer)


if __name__ == "__main__":
    main()