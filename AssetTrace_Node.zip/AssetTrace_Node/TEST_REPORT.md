# Test Report — AssetTrace Node v2 Parco Macchine

Data test: 2026-06-23

## Esito generale

AssetTrace Node v2 Parco Macchine è stato testato con esito positivo dopo una correzione sul comando `/addguasto`.

## Test eseguiti

- Decompressione dello ZIP.
- Controllo struttura cartelle.
- Compilazione sintattica Python di:
  - `app.py`
  - `config.py`
  - `core/*.py`
  - `tools/*.py`
  - `memory/*.py`
- Avvio CLI con `python app.py`.
- Comando `/docs`.
- Comando `/macchine`.
- Comando `/macchina MAC-001`.
- Comando `/stato MAC-001 manutenzione`.
- Comando `/addmacchina`.
- Comando `/eventomacchina MAC-003`.
- Comando `/addguasto` collegato a `MAC-001`.
- Verifica collegamento evento guasto nello storico macchina.
- Verifica comportamento senza Ollama attivo.
- Verifica modulo web in ambiente senza DNS/internet.

## Bug trovato e corretto

Nel file `memory/guasti.py`, il comando `/addguasto` usava la variabile `machine_id` senza averla definita.

Correzione introdotta:

- richiesta opzionale dell'ID macchina durante `/addguasto`;
- validazione con `get_machine(machine_id)`;
- se la macchina non esiste, il guasto viene salvato senza collegamento;
- se la macchina esiste, il guasto viene collegato allo storico eventi della macchina.

## Note

- Senza Ollama attivo, AssetTrace mostra correttamente il messaggio di errore e non va in crash.
- Nel sandbox di test la ricerca web non ha potuto risolvere DNS/internet, ma il modulo gestisce l'errore senza crash.
- Su PC/Raspberry con internet attivo, `/web <query>` dovrebbe tentare la ricerca DuckDuckGo HTML.

## Avvio consigliato

```powershell
cd AssetTrace_Node_v2_parco_macchine
py .\app.py
```

## Comandi principali

```text
/docs
/macchine
/macchina MAC-001
/addmacchina
/stato MAC-001 manutenzione
/eventomacchina MAC-001
/addguasto
/web OctoPrint non si avvia automaticamente Raspberry Pi
/exit
```
