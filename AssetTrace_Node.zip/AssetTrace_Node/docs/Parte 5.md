# PARTE 5 — Gestione del parco macchine e memoria tecnica degli asset

## Funzione della Parte 5

La Parte 5 introduce in AssetTrace la gestione del **parco macchine**.

Questa parte collega l'architettura teorica alle entità fisiche o digitali reali che il sistema deve osservare nel tempo.

Una macchina può essere:

- stampante 3D;
- Raspberry Pi;
- server NAS;
- PC;
- rete;
- sensore;
- modulo elettronico;
- dashboard;
- impianto o sottosistema tecnico.

Il parco macchine non è una semplice anagrafica.

È la memoria strutturale degli asset su cui AssetTrace osserva, collega guasti, valuta rischio, registra eventi e propone cicli di manutenzione.

---

## 5.1 Perché serve il parco macchine

Senza parco macchine, un guasto resta isolato.

Esempio:

```text
Guasto: T0 abnormal
```

Con il parco macchine, il guasto diventa parte di un contesto:

```text
Macchina: MAC-001 — Anycubic Chiron
Categoria: stampante_3d
Controller: OctoPrint su Raspberry Pi 3
Stato: osservazione
Criticità: 4/5
Guasto collegato: T0 abnormal
Eventi recenti: mesh bed, cablaggio, dashboard assi, OctoPrint
```

Questo permette ad AssetTrace di capire non solo **che cosa è successo**, ma **dove**, **su quale macchina**, **con quale storico** e **con quale impatto sistemico**.

---

## 5.2 Posizione architetturale

Il parco macchine si collega alle quattro parti precedenti.

### Collegamento con la Parte 1

La macchina è un punto concreto immerso nella melma.

La melma trasporta segnali provenienti da:

- guasti;
- log;
- temperature;
- tempi reali;
- delta rispetto al teorico;
- manutenzioni;
- rumore operativo;
- osservazioni manuali.

I nodi informativi elaborano questi segnali per generare pattern, dubbio e ipotesi.

Il legante mantiene coerenza tra macchina, eventi, guasti e cicli.

---

### Collegamento con la Parte 2

Ogni macchina può avere cicli evolutivi propri:

1. osservazione;
2. adattamento locale;
3. espansione se il problema persiste;
4. chiusura del ciclo;
5. passaggio temporale;
6. ottimizzazione;
7. nuovo ciclo.

Il parco macchine permette di distinguere:

- ciclo della macchina;
- ciclo del guasto;
- ciclo del sistema AssetTrace;
- ciclo del parco intero.

---

### Collegamento con la Parte 3

Ogni macchina ha un impatto sistemico diverso.

Una macchina critica richiede più prudenza.

Il governo valuta:

- criticità;
- reversibilità dell'intervento;
- rischio fisico o elettrico;
- rischio dati;
- costo operativo;
- propagazione del guasto;
- responsabilità umana.

AssetTrace non deve agire direttamente sulla macchina.

Può osservare, classificare, proporre test e suggerire manutenzione.

---

### Collegamento con la Parte 4

Quando la memoria interna non basta, il modulo web può cercare informazioni esterne riferite a una macchina specifica.

Esempio:

```text
/web Anycubic Chiron T0 abnormal thermistor cable
```

La ricerca viene collegata alla macchina e al guasto, ma non diventa automaticamente verità.

Resta una osservazione esterna governata.

---

## 5.3 Scheda minima macchina

Ogni macchina dovrebbe contenere almeno:

```json
{
  "id": "MAC-001",
  "nome": "Anycubic Chiron",
  "categoria": "stampante_3d",
  "modello": "Anycubic Chiron",
  "posizione": "laboratorio",
  "ip": "192.168.1.50",
  "url_controllo": "http://192.168.1.50",
  "stato": "attiva / osservazione / manutenzione / ferma / dismessa",
  "criticita": 4,
  "note": "Stampante principale collegata a OctoPrint",
  "eventi": [],
  "guasti_collegati": [],
  "ricerche_web_collegate": [],
  "cicli_collegati": []
}
```

---

## 5.4 Stati macchina

Gli stati consigliati sono:

### Attiva

La macchina funziona ed è utilizzabile.

### Osservazione

La macchina funziona, ma presenta segnali deboli o anomalie.

### Manutenzione

La macchina richiede intervento o test.

### Ferma

La macchina non è operativa.

### Dismessa

La macchina non è più parte del ciclo operativo.

---

## 5.5 Criticità

La criticità va da 1 a 5.

```text
1 = bassa
2 = medio-bassa
3 = media
4 = alta
5 = critica
```

La criticità non misura solo il valore economico.

Misura l'impatto sistemico:

- quanto blocca il lavoro;
- quanto influenza altri nodi;
- quanto è rischiosa una modifica;
- quanto è difficile ripristinarla;
- quanto apprendimento contiene.

---

## 5.6 Eventi macchina

Ogni macchina può avere eventi.

Tipi di evento:

- creazione;
- manutenzione;
- controllo;
- guasto;
- cambio stato;
- aggiornamento;
- ricerca web;
- nota;
- decisione umana.

Gli eventi permettono di costruire una storia tecnica.

---

## 5.7 Output operativo

Quando AssetTrace risponde su una macchina, dovrebbe distinguere:

```text
Macchina coinvolta:
...

Segnali osservati:
...

Storico rilevante:
...

Stato attuale:
...

Criticità:
...

Ipotesi:
...

Test minimo reversibile:
...

Azione da non forzare:
...
```

---

## 5.8 Sintesi

La Parte 5 trasforma AssetTrace da nodo che analizza eventi singoli a sistema che segue un insieme di macchine nel tempo.

In una frase:

> Il parco macchine è la memoria degli asset reali di AssetTrace: collega macchine, guasti, eventi, ricerche web e cicli evolutivi, mantenendo ogni intervento tracciabile, prudente e governato.
