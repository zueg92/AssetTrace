# PARTE 4 — Percezione esterna e ricerca web real-time

## Funzione della Parte 4

La Parte 4 introduce nell’architettura "AssetTrace" un modulo di **percezione esterna aggiornata**, basato su ricerca web real-time o quasi real-time.

Questa parte non trasforma "AssetTrace" in un agente autonomo connesso al mondo.

La sua funzione è più precisa:

- osservare informazioni esterne aggiornate;
- verificare dati che potrebbero essere cambiati;
- confrontare fonti diverse;
- rilevare novità, contraddizioni e obsolescenze;
- alimentare la melma con segnali esterni tracciabili;
- supportare i nodi informativi nella generazione di ipotesi;
- restituire all’umano scenari più informati, non decisioni automatiche.

Il web non è una verità superiore alla memoria interna.

Il web è una **sorgente esterna di segnali**.

---

## 4.1 Collocazione architetturale

Il modulo web si colloca tra:

- ambiente esterno;
- melma informativa;
- nodi informativi;
- legante;
- governo sistemico.

Non è un quarto organo strutturale al pari di melma, nodi e legante.

È un **canale percettivo esterno**.

La Parte 1 resta quindi valida: l’anatomia fondamentale del sistema rimane composta da:

1. melma;
2. nodi informativi;
3. legante.

Il modulo web non modifica questa anatomia.

Agisce come interfaccia tra mondo esterno e melma.

```text
Mondo esterno
     ↓
Modulo web real-time
     ↓
Segnali esterni tracciati
     ↓
Melma informativa
     ↓
Nodi informativi
     ↓
Ipotesi / dubbio / adattamento
     ↓
Governo sistemico
     ↓
Output umano
```

---

## 4.2 Perché il modulo web è necessario

Un sistema che opera solo sulla memoria interna rischia di diventare:

- autoreferenziale;
- obsoleto;
- chiuso rispetto al cambiamento;
- incapace di riconoscere aggiornamenti tecnici;
- troppo dipendente da esperienze passate.

Questo è particolarmente importante in ambiti come:

- guasti tecnici;
- firmware;
- librerie software;
- API;
- prezzi;
- normative;
- documentazione online;
- repository;
- compatibilità hardware;
- procedure operative.

In questi casi, una conoscenza corretta ieri può non essere più corretta oggi.

La Parte 4 serve quindi a impedire che "AssetTrace" confonda la propria memoria con il mondo reale aggiornato.

---

## 4.3 Differenza tra memoria interna e ricerca web

"AssetTrace" distingue due sorgenti conoscitive.

### Memoria interna

Comprende:

- guasti già osservati;
- soluzioni già testate;
- cicli precedenti;
- configurazioni locali;
- pattern ricorrenti;
- decisioni umane passate;
- conoscenza stabilizzata.

La memoria interna garantisce:

- continuità;
- identità;
- apprendimento nel tempo;
- profondità contestuale.

### Ricerca web real-time

Comprende:

- documentazione aggiornata;
- discussioni tecniche recenti;
- changelog;
- issue GitHub;
- forum;
- manuali;
- pagine ufficiali;
- notizie;
- dati variabili nel tempo.

La ricerca web garantisce:

- aggiornamento;
- confronto esterno;
- rilevazione di novità;
- verifica dell’obsolescenza;
- apertura verso il mondo.

Sintesi:

```text
Memoria interna = profondità temporale
Web real-time   = aggiornamento esterno
```

AssetTrace non deve scegliere ciecamente una delle due.

Deve confrontarle.

---

## 4.4 Principio fondamentale

Il modulo web non decide.

Il modulo web:

- cerca;
- raccoglie;
- confronta;
- classifica;
- segnala;
- produce ipotesi;
- esplicita incertezza.

Non può:

- agire direttamente sul mondo;
- modificare configurazioni critiche;
- eseguire codice trovato online senza verifica;
- cancellare conoscenza interna;
- sostituire la decisione umana;
- trasformare una fonte web in verità assoluta.

La ricerca web aumenta la capacità percettiva di AssetTrace, ma resta sottoposta al governo sistemico della Parte 3.

---

## 4.5 Quando si attiva il modulo web

Il modulo web non deve essere sempre attivo.

Si attiva quando compare almeno una delle seguenti condizioni.

### 1. Sorpresa persistente

Un evento non viene spiegato dalla memoria interna.

Esempio:

- un errore tecnico non corrisponde ai guasti già registrati;
- una procedura nota non funziona più;
- un comportamento del sistema appare nuovo.

---

### 2. Informazione temporalmente instabile

La risposta dipende da dati che possono cambiare nel tempo.

Esempi:

- versioni software;
- prezzi API;
- firmware;
- normative;
- compatibilità;
- guide tecniche;
- disponibilità di componenti;
- procedure ufficiali.

---

### 3. Contraddizione interna

La memoria contiene informazioni incompatibili tra loro.

Il web viene usato per cercare fonti esterne che aiutino a stabilire:

- quale informazione è più aggiornata;
- quale è più affidabile;
- quale va mantenuta come dubbia.

---

### 4. Guasto non riconosciuto

Quando un guasto non rientra nei pattern interni, il modulo web può cercare casi simili.

Esempio:

```text
Guasto locale:
Anycubic Chiron
Errore: T0 abnormal
Sintomo: temperatura 0°C
Ipotesi: cavo multipolare, termistore, scheda hotend
```

La ricerca web può cercare:

- casi simili;
- pinout;
- discussioni tecniche;
- firmware collegati;
- documentazione del produttore;
- soluzioni già testate da altri utenti.

---

### 5. Richiesta esplicita dell’umano

L’utente può chiedere direttamente:

- “verifica online”;
- “cerca la versione aggiornata”;
- “controlla se è cambiato”;
- “trova casi simili”;
- “confronta più fonti”.

In questo caso il modulo web viene attivato come estensione della domanda umana.

---

## 4.6 Pipeline del modulo web

Il modulo web opera secondo una pipeline controllata.

### Fase 1 — Formulazione della domanda

La richiesta viene trasformata in una query precisa.

Una buona query deve essere:

- specifica;
- verificabile;
- limitata;
- legata al contesto;
- non eccessivamente generica.

Esempi:

```text
"OctoPrint non si avvia automaticamente Raspberry Pi systemd"
"Anycubic Chiron T0 abnormal termistor cable"
"Marlin EEPROM mesh bed leveling save M500"
"OpenAI API web search pricing"
```

---

### Fase 2 — Ricerca multi-fonte

Il sistema consulta più tipi di fonte, quando possibile:

- documentazione ufficiale;
- repository GitHub;
- issue tracker;
- forum tecnici;
- manuali;
- changelog;
- discussioni specialistiche;
- pagine istituzionali;
- articoli tecnici.

Le fonti non hanno tutte lo stesso peso.

In generale hanno peso maggiore:

1. documentazione ufficiale;
2. repository o issue tecniche verificabili;
3. manuali e changelog;
4. forum con prove concrete;
5. articoli tecnici con data e autore;
6. contenuti generici senza riferimenti.

---

### Fase 3 — Valutazione della freschezza

Ogni fonte viene valutata rispetto al tempo.

Parametri minimi:

- data della ricerca;
- data di pubblicazione;
- data di aggiornamento;
- probabilità di obsolescenza;
- rilevanza rispetto alla versione attuale del problema.

La freschezza è decisiva quando l’informazione riguarda:

- API;
- firmware;
- librerie;
- normative;
- prezzi;
- compatibilità;
- sicurezza;
- procedure operative.

---

### Fase 4 — Valutazione dell’affidabilità

Ogni fonte viene valutata secondo criteri di affidabilità.

Criteri possibili:

- autorevolezza della fonte;
- presenza di dettagli tecnici;
- presenza di prove;
- coerenza con altre fonti;
- chiarezza della data;
- compatibilità con la memoria interna;
- rischio di contenuto copiato, incompleto o generato automaticamente;
- rischio di istruzioni pericolose o non verificate.

Il modulo web non deve accettare una fonte solo perché appare nei primi risultati.

---

### Fase 5 — Produzione della scheda di osservazione esterna

Il risultato della ricerca non entra subito nella memoria stabile.

Prima viene trasformato in una **scheda di osservazione esterna**.

La scheda contiene:

- domanda iniziale;
- query usate;
- fonti consultate;
- sintesi dei risultati;
- livello di affidabilità;
- livello di freschezza;
- contraddizioni trovate;
- ipotesi generate;
- incertezza residua;
- azioni suggerite;
- necessità di conferma umana.

---

### Fase 6 — Immissione nella melma

La scheda viene immessa nella melma come segnale esterno tracciato.

Non entra come verità.

Entra come:

- conferma;
- aggiornamento;
- contraddizione;
- novità;
- rumore;
- ipotesi;
- limite.

I nodi informativi possono poi lavorarla.

---

### Fase 7 — Elaborazione nei nodi

I nodi informativi confrontano la scheda web con:

- memoria locale;
- guasti precedenti;
- pattern già emersi;
- cicli in corso;
- vincoli del legante;
- limiti della Parte 3.

A questo punto possono emergere:

- nuove ipotesi;
- dubbio strutturale;
- adattamento locale;
- proposta di espansione;
- proposta di aggiornamento della memoria;
- richiesta di ulteriore verifica.

---

### Fase 8 — Output governato

L’output finale deve sempre distinguere:

- cosa è noto;
- cosa è probabile;
- cosa è incerto;
- cosa è contraddittorio;
- cosa richiede test;
- cosa richiede decisione umana.

L’output non deve presentarsi come comando.

Deve presentarsi come supporto decisionale.

---

## 4.7 Classificazione dei risultati web

Ogni risultato web viene classificato in una delle seguenti categorie.

### Conferma

Il web conferma ciò che AssetTrace già sapeva.

Effetto:

- rafforza la memoria interna;
- aumenta la fiducia locale;
- riduce la necessità di espansione.

---

### Aggiornamento

Il web mostra che una conoscenza interna è superata.

Effetto:

- marca la conoscenza precedente come obsoleta;
- propone aggiornamento;
- attiva adattamento locale.

---

### Contraddizione

Il web produce informazioni incompatibili con la memoria interna o tra fonti diverse.

Effetto:

- attiva il dubbio nei nodi;
- blocca conclusioni premature;
- richiede ulteriore verifica;
- può richiedere intervento umano.

---

### Novità

Il web introduce una variabile non presente nello spazio interno.

Effetto:

- possibile espansione;
- creazione di nuovo nodo informativo;
- generazione di nuova ipotesi.

---

### Rumore

Il web produce informazioni deboli, generiche o non verificabili.

Effetto:

- non modifica la memoria stabile;
- può restare nella melma come segnale debole;
- non attiva espansione da solo.

---

### Rischio

Il web produce contenuti potenzialmente dannosi, manipolativi o non sicuri.

Effetto:

- isolamento;
- segnalazione all’umano;
- esclusione dall’adattamento automatico;
- eventuale archiviazione come fonte non affidabile.

---

## 4.8 Relazione con la Parte 1

La Parte 4 non modifica la struttura di base della Parte 1.

La rafforza.

### Melma

Il web alimenta la melma con segnali esterni.

La melma resta però ciò che era:

- infrastruttura di circolazione;
- spazio di trasporto;
- ambiente informativo distribuito.

Il modulo web non interpreta al posto della melma.

Immette segnali nella melma.

---

### Nodi informativi

I nodi ricevono dalla melma anche segnali provenienti dal web.

Nei nodi possono emergere:

- pattern esterni;
- ipotesi;
- confronto tra memoria e mondo;
- dubbio;
- abduzione;
- nuove rappresentazioni.

Il web non sostituisce i nodi.

Li alimenta.

---

### Legante

Il legante impedisce che informazioni web instabili frammentino il sistema.

Garantisce:

- continuità;
- compatibilità;
- tracciabilità;
- coerenza;
- identità nel tempo.

Il legante impedisce che ogni nuova fonte web produca una mutazione incontrollata.

---

## 4.9 Relazione con la Parte 2

La Parte 4 si integra nella dinamica a cicli.

### Osservazione

Il web arricchisce la fase di osservazione con segnali esterni.

### Adattamento locale

Se il web conferma un’informazione o aggiorna una procedura semplice, il sistema può proporre un adattamento locale.

### Espansione

Se il web introduce variabili nuove o contraddizioni persistenti, può attivare una proposta di espansione.

### Chiusura del ciclo

La ricerca viene salvata come osservazione, non come verità assoluta.

### Passaggio temporale

Il tempo permette di verificare se l’informazione web resta valida.

### Ottimizzazione

Ricerche ripetute, fonti ridondanti e pattern ricorrenti possono essere compattati.

Esempio:

```text
Molte ricerche diverse confermano che un certo errore dipende spesso da un cavo.
Dopo più cicli, AssetTrace può compattare questo pattern come ipotesi prioritaria,
ma non come certezza automatica.
```

---

## 4.10 Relazione con la Parte 3

La Parte 4 deve essere subordinata al governo sistemico.

Il web introduce potenza, ma anche rischio.

Rischi principali:

- fonti false;
- fonti obsolete;
- contenuti generati automaticamente;
- istruzioni tecniche pericolose;
- manipolazione;
- prompt injection;
- conflitto tra fonti;
- sovraccarico informativo;
- falsa certezza.

Per questo il modulo web deve rispettare alcuni vincoli.

### Vincolo 1 — Nessuna azione diretta

Il modulo web non agisce direttamente sul mondo.

Può suggerire, ma non eseguire.

---

### Vincolo 2 — Tracciabilità delle fonti

Ogni informazione esterna deve mantenere collegamento a:

- fonte;
- data;
- query;
- contesto;
- livello di affidabilità.

---

### Vincolo 3 — Esplicitazione dell’incertezza

Se le fonti sono deboli o contraddittorie, il sistema deve dirlo.

Non deve simulare certezza.

---

### Vincolo 4 — Conferma umana per azioni critiche

Le azioni critiche richiedono conferma umana.

Esempi:

- modificare firmware;
- eseguire comandi di sistema;
- cambiare configurazioni di rete;
- modificare impianti elettrici;
- cancellare dati;
- aggiornare memoria stabile;
- applicare procedure rischiose.

---

### Vincolo 5 — Separazione tra informazione e decisione

Il web fornisce informazione.

La decisione resta esterna al sistema.

---

## 4.11 Schema dati minimo

Ogni ricerca web dovrebbe essere registrata con una struttura minima.

```json
{
  "id": "web_obs_0001",
  "data_ricerca": "2026-06-14T10:30:00+02:00",
  "motivo_attivazione": "guasto_non_riconosciuto",
  "domanda": "Perché OctoPrint non si avvia automaticamente?",
  "query_usate": [
    "OctoPrint not starting automatically Raspberry Pi systemd",
    "OctoPrint enable service boot Raspberry Pi"
  ],
  "fonti": [
    {
      "titolo": "Titolo della fonte",
      "url": "https://...",
      "tipo": "documentazione / forum / repository / articolo",
      "data_pubblicazione": null,
      "data_aggiornamento": null,
      "affidabilita": 0.0,
      "freschezza": 0.0,
      "sintesi": "Sintesi breve del contenuto utile"
    }
  ],
  "classificazione": "conferma / aggiornamento / contraddizione / novita / rumore / rischio",
  "ipotesi_generate": [
    "Il servizio non è abilitato all'avvio",
    "Il path del virtualenv non è corretto",
    "Il processo fallisce per permessi insufficienti"
  ],
  "incertezza_residua": "Manca lettura diretta dei log locali",
  "azione_consigliata": "Controllare systemctl status octoprint",
  "richiede_conferma_umano": true,
  "collegamenti_interni": {
    "guasto_id": null,
    "ciclo_id": null,
    "nodo_coinvolto": null
  }
}
```

---

## 4.12 Integrazione con la memoria dei guasti

Quando AssetTrace lavora su un guasto, il modulo web può essere collegato alla memoria tecnica.

Flusso consigliato:

1. registrare il guasto locale;
2. cercare nella memoria interna casi simili;
3. se la memoria non basta, attivare il modulo web;
4. raccogliere fonti esterne;
5. confrontare sintomi e soluzioni;
6. generare ipotesi ordinate;
7. proporre test locali;
8. salvare la ricerca collegata al guasto;
9. aggiornare il ciclo evolutivo.

Esempio:

```text
Guasto:
- Sistema: Anycubic Chiron
- Sintomo: T0 abnormal
- Temperatura: 0°C
- Test locale: continuità intermittente su cavo multipolare

Ricerca web:
- casi simili
- pinout
- termistore
- firmware
- scheda hotend

Output:
- ipotesi A: cavo interrotto
- ipotesi B: termistore difettoso
- ipotesi C: falso contatto sulla scheda
- test consigliato: continuità pin-to-pin e lettura ohmica
```

---

## 4.13 Integrazione con i cicli evolutivi

Ogni ricerca web può generare o alimentare un ciclo.

### Ciclo tipo

```text
Osservazione:
compare un guasto non riconosciuto.

Adattamento locale:
si confronta con la memoria interna.

Espansione:
il web introduce una nuova variabile tecnica.

Chiusura:
si salva una scheda di osservazione esterna.

Tempo:
si verifica se la soluzione proposta funziona.

Ottimizzazione:
se il pattern si ripete, viene compattato nella memoria dei guasti.
```

Questo permette ad AssetTrace di non accumulare solo dati, ma di trasformare l’esperienza in struttura.

---

## 4.14 Livelli di fiducia del modulo web

La fiducia non deve essere binaria.

Ogni risultato può avere un livello.

### Fiducia alta

Condizioni:

- fonte ufficiale;
- informazione recente;
- conferma da più fonti;
- coerenza con memoria interna;
- prove tecniche presenti.

### Fiducia media

Condizioni:

- fonte non ufficiale ma tecnica;
- esperienza documentata;
- conferme parziali;
- compatibilità plausibile.

### Fiducia bassa

Condizioni:

- fonte generica;
- nessuna data;
- nessuna prova;
- contenuto copiato;
- informazioni contraddittorie.

### Fiducia bloccante

Condizioni:

- rischio tecnico;
- istruzioni distruttive;
- contenuto manipolativo;
- impossibilità di verifica;
- impatto sistemico elevato.

In caso di fiducia bloccante, il sistema non procede.

Restituisce il limite all’umano.

---

## 4.15 Output standard del modulo web

Ogni output del modulo web dovrebbe seguire una forma leggibile.

```text
Risultato ricerca web

Domanda:
...

Cosa emerge:
...

Fonti più affidabili:
...

Fonti deboli o contraddittorie:
...

Ipotesi generate:
1.
2.
3.

Cosa resta incerto:
...

Test o azione consigliata:
...

Serve conferma umana:
sì / no
```

Questo mantiene l’output interpretabile e compatibile con il ruolo di supporto decisionale.

---

## 4.16 Possibile implementazione tecnica

In una prima versione Python, il modulo può essere composto da:

```text
antinea_web.py
```

Funzioni minime:

```python
crea_query()
esegui_ricerca()
valuta_fonte()
classifica_risultato()
crea_scheda_web()
collega_a_guasto()
collega_a_ciclo()
salva_osservazione_web()
```

Cartella consigliata:

```text
assettrace_node/
│
├── assettrace_node.py
├── antinea_web.py
├── antinea_guasti.py
├── antinea_cicli.py
│
└── memoria/
    ├── guasti/
    ├── ricerche_web/
    ├── cicli/
    └── decisioni_umane/
```

Il modulo web può essere inizialmente manuale o semi-automatico.

In una fase successiva può usare:

- API di ricerca;
- scraping controllato;
- fonti whitelist;
- repository tecnici;
- documentazione ufficiale;
- cache locale;
- memoria delle ricerche.

---

## 4.17 Cosa non deve fare la Parte 4

La Parte 4 non deve:

- trasformare AssetTrace in un crawler incontrollato;
- creare dipendenza continua dal web;
- sostituire la memoria interna;
- aggiungere un centro decisionale;
- eliminare il ruolo umano;
- confondere aggiornamento con verità;
- confondere quantità di fonti con qualità;
- attivare espansioni continue.

Il web è utile solo se resta governato.

---

## 4.18 Sintesi strutturale

La Parte 4 aggiunge ad AssetTrace la capacità di confrontarsi con il mondo esterno aggiornato.

Il modulo web real-time permette di:

- cercare informazioni recenti;
- verificare conoscenze interne;
- riconoscere obsolescenza;
- trovare casi simili;
- generare ipotesi tecniche;
- alimentare i cicli evolutivi;
- migliorare la memoria dei guasti;
- esplicitare incertezza e limiti.

Ma resta subordinato a:

- melma;
- nodi;
- legante;
- cicli;
- governo sistemico;
- responsabilità umana.

In una frase:

> La Parte 4 è l’organo percettivo esterno di AssetTrace: porta il mondo nella melma, ma lascia ai nodi l’elaborazione, al legante la coesione e al governo sistemico il controllo dei limiti.

---

## Collegamento alle parti precedenti

- La Parte 1 definisce la struttura.
- La Parte 2 definisce il movimento nel tempo.
- La Parte 3 definisce i limiti e il governo.
- La Parte 4 introduce la percezione esterna aggiornata.

```text
Parte 1 = anatomia
Parte 2 = fisiologia
Parte 3 = governo
Parte 4 = percezione esterna
```

Senza la Parte 4, AssetTrace apprende soprattutto dalla memoria interna.

Con la Parte 4, AssetTrace può confrontare la propria memoria con il mondo reale, senza perdere governabilità.
