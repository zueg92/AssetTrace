# PARTE 6 — Patterns, health index e apprendimento leggero

## Funzione della Parte 6

La Parte 6 introduce il riconoscimento dei **patterns** nel Nodo AssetTrace.

Questa parte non modifica i pesi del modello linguistico e non trasforma Ollama in un sistema che apprende da solo.

La funzione è diversa:

- osservare ricorrenze;
- contare eventi;
- collegare guasti e macchine;
- stimare fragilità;
- produrre un health index;
- evidenziare priorità manutentive;
- suggerire azioni minime, reversibili e testabili.

In questa fase AssetTrace non fa machine learning pesante.

Fa **apprendimento leggero strutturale**, basato sulla memoria tecnica locale.

---

## 6.1 Differenza tra memoria e pattern

La memoria conserva eventi, guasti, macchine, ricerche e conversazioni.

Il modulo patterns li attraversa e cerca segnali ricorrenti.

Esempio:

```text
MAC-001 ha avuto più eventi di tipo guasto.
Nei titoli ricorrono T0, cavo, termistore.
Lo stato è manutenzione.
La criticità è 4/5.
```

Da questo AssetTrace non deve produrre una certezza assoluta.

Deve produrre una priorità di osservazione.

---

## 6.2 Health index

L'health index è un indice sintetico da 0 a 100.

Tiene conto di:

- stato macchina;
- criticità;
- numero di eventi;
- presenza di guasti;
- impatto degli eventi;
- ricorrenze nel tempo.

Non è una diagnosi.

È un segnale di governo.

---

## 6.3 Output del modulo patterns

Il modulo patterns deve restituire:

- macchine più fragili;
- eventi ricorrenti;
- termini ricorrenti;
- guasti collegati;
- livello di rischio;
- prossima azione minima.

---

## 6.4 Vincolo di sicurezza

Un pattern non deve mai diventare comando automatico.

Può solo:

- segnalare;
- proporre;
- ordinare priorità;
- supportare il ciclo evolutivo.

La decisione resta all'umano.
