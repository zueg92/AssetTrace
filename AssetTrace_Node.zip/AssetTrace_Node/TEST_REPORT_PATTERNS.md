# Test report — Patterns

Verifiche eseguite:

- Compilazione sintassi Python: OK.
- Import principali: OK.
- Init database SQLite: OK.
- Seed macchine esempio: OK.
- `/health`: modulo disponibile.
- `/patterns`: modulo disponibile.
- `/patterns MAC-001`: modulo disponibile.
- `/ollama`: check servizio disponibile.

File aggiunti:

```text
memory/patterns.py
docs/Parte 6.md
```

Comandi nuovi:

```text
/health
/patterns
/patterns MAC-001
```
