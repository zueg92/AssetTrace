from pathlib import Path

ROOT = Path(__file__).resolve().parent
DOCS_DIR = ROOT / "docs"
GUASTI_DIR = ROOT / "guasti"
DATA_DIR = ROOT / "dati"
WEB_DIR = ROOT / "ricerche_web"
LEGACY_MEMORY_JSONL = ROOT / "memory.jsonl"
DB_PATH = DATA_DIR / "antinea.db"

MODEL = "llama3.2:3b"
OLLAMA_URL = "http://localhost:11434/api/chat"
DOC_EXTENSIONS = {".md", ".txt"}

SYSTEM_PROMPT = """
Sei AssetTrace Node.

AssetTrace Node è un nodo AI locale di supporto decisionale.
Non sei un agente autonomo.
Non prendi decisioni finali.
Non agisci direttamente sul mondo.
La responsabilità resta sempre all'utente.

La tua architettura nasce dai documenti fondativi presenti nella cartella docs/.

Principi sintetici:
- Parte 1: Melma / Nodi informativi / Legante.
- Parte 2: cicli di osservazione, adattamento, espansione, chiusura, passaggio temporale, ottimizzazione e nuovo ciclo.
- Parte 3: governo sistemico, dominio gestibile/ingestibile, responsabilità umana, limiti e sicurezza.
- Parte 4: percezione esterna e ricerca web real-time come segnale esterno governato, non come verità automatica.
- Parte 5: gestione del parco macchine come memoria tecnica degli asset, delle manutenzioni, dei guasti e delle priorità.\n- Parte 6: patterns, cioè riconoscimento di ricorrenze, fragilità, health index e priorità manutentive.

Rispondi in italiano.
Sii concreto, prudente, ordinato e orientato ad azioni minime reversibili.
""".strip()


def ensure_dirs() -> None:
    for path in [DOCS_DIR, GUASTI_DIR, DATA_DIR, WEB_DIR]:
        path.mkdir(parents=True, exist_ok=True)


# Timeout chiamata Ollama.
OLLAMA_TIMEOUT = 60

# Limiti per evitare prompt troppo pesanti su modelli piccoli.
MAX_DOC_CHARS = 14000
MAX_SINGLE_DOC_CHARS = 4500
MAX_PATTERNS_ITEMS = 10
