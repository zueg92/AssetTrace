# AssetTrace Node

AssetTrace Node è un nodo locale per:

- gestione del parco macchine;
- memoria dei guasti;
- tracciamento degli eventi tecnici;
- ricerca web governata;
- analisi leggera dei pattern manutentivi;
- health index delle macchine.

È un modo di sviluppo operativo di un'architettura madre più ampia, orientato alla memoria tecnica e al supporto decisionale nella manutenzione.

AssetTrace Node non è un agente autonomo: non prende decisioni finali, non agisce direttamente sul mondo e mantiene la responsabilità decisionale sull'utente.

---

## Avvio

Apri PowerShell nella cartella del progetto:

```powershell
cd AssetTrace_Node
py .\app.py
```

Se `py` non funziona:

```powershell
python .\app.py
```

---

## Ollama

AssetTrace Node usa Ollama in locale.

```powershell
ollama serve
ollama list
ollama pull llama3.2:3b
```

Dentro AssetTrace Node puoi usare:

```text
/ollama
```

---

## Comandi principali

```text
/docs
/mem
/macchine
/health
/patterns
/patterns MAC-001
/macchina MAC-001
/stato MAC-001 manutenzione
/eventomacchina MAC-001
/addmacchina
/addguasto
/web <query>
/ollama
/help
/exit
```

---

## Moduli principali

### Parco macchine

Gestisce gli asset tecnici: stampanti 3D, Raspberry, server, PC, sensori, nodi locali e altri dispositivi.

### Guasti

Registra guasti in formato leggibile e collegabile alle macchine.

### Patterns

Analizza eventi, guasti e stati macchina per produrre health index, macchine fragili, eventi ricorrenti e prossima azione minima.

### Web

Porta segnali esterni aggiornati, ma non li tratta come verità automatica.

---

## Nome repository consigliato

```text
assettrace-node
```

Descrizione breve:

```text
Local maintenance intelligence node for machine park management, fault memory and lightweight pattern analysis.
```
