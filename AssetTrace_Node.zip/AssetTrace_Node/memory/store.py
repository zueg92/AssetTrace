import json
import sqlite3
from pathlib import Path
from typing import Dict, List, Optional

from config import DB_PATH, DATA_DIR, LEGACY_MEMORY_JSONL


def connect() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS chat_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                user_text TEXT NOT NULL,
                antinea_answer TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS web_observations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                query TEXT NOT NULL,
                ok INTEGER NOT NULL,
                raw_json TEXT NOT NULL,
                antinea_answer TEXT
            )
            """
        )

        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS machine_assets (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                model TEXT,
                location TEXT,
                ip_address TEXT,
                controller_url TEXT,
                status TEXT NOT NULL,
                criticality INTEGER NOT NULL DEFAULT 3,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                notes TEXT,
                metadata_json TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS machine_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                machine_id TEXT NOT NULL,
                event_type TEXT NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                impact TEXT,
                payload_json TEXT,
                FOREIGN KEY(machine_id) REFERENCES machine_assets(id)
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS system_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL
            )
            """
        )
        conn.commit()
    import_legacy_memory_once()


def save_chat(timestamp: str, user_text: str, antinea_answer: str) -> None:
    with connect() as conn:
        conn.execute(
            "INSERT INTO chat_memory(timestamp, user_text, antinea_answer) VALUES (?, ?, ?)",
            (timestamp, user_text, antinea_answer),
        )
        conn.commit()


def load_recent_chat(limit: int = 8) -> List[Dict[str, str]]:
    with connect() as conn:
        rows = conn.execute(
            "SELECT timestamp, user_text, antinea_answer FROM chat_memory ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    rows = list(reversed(rows))
    return [dict(row) for row in rows]


def save_web_observation_db(timestamp: str, query: str, ok: bool, raw: Dict, antinea_answer: Optional[str]) -> None:
    with connect() as conn:
        conn.execute(
            "INSERT INTO web_observations(timestamp, query, ok, raw_json, antinea_answer) VALUES (?, ?, ?, ?, ?)",
            (timestamp, query, 1 if ok else 0, json.dumps(raw, ensure_ascii=False), antinea_answer),
        )
        conn.commit()


def log_event(timestamp: str, event_type: str, payload: Dict) -> None:
    with connect() as conn:
        conn.execute(
            "INSERT INTO system_events(timestamp, event_type, payload_json) VALUES (?, ?, ?)",
            (timestamp, event_type, json.dumps(payload, ensure_ascii=False)),
        )
        conn.commit()


def import_legacy_memory_once() -> None:
    marker = DATA_DIR / ".legacy_memory_imported"
    if marker.exists() or not LEGACY_MEMORY_JSONL.exists():
        return

    imported = 0
    with connect() as conn:
        for line in LEGACY_MEMORY_JSONL.read_text(encoding="utf-8", errors="ignore").splitlines():
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            conn.execute(
                "INSERT INTO chat_memory(timestamp, user_text, antinea_answer) VALUES (?, ?, ?)",
                (
                    item.get("timestamp", "legacy"),
                    item.get("user", ""),
                    item.get("antinea", ""),
                ),
            )
            imported += 1
        conn.commit()

    marker.write_text(f"imported={imported}\n", encoding="utf-8")
