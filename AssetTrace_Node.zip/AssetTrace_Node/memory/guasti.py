import re
from datetime import datetime
from pathlib import Path
from typing import List

from config import GUASTI_DIR
from memory.parco_macchine import get_machine, add_machine_event


def slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[àáâä]", "a", text)
    text = re.sub(r"[èéêë]", "e", text)
    text = re.sub(r"[ìíîï]", "i", text)
    text = re.sub(r"[òóôö]", "o", text)
    text = re.sub(r"[ùúûü]", "u", text)
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_")[:60] or "guasto"


def next_guasto_id() -> str:
    GUASTI_DIR.mkdir(parents=True, exist_ok=True)
    ids = []
    for file in GUASTI_DIR.rglob("GUA-*.md"):
        match = re.search(r"GUA-(\d+)", file.name)
        if match:
            ids.append(int(match.group(1)))
    return f"GUA-{max(ids, default=0) + 1:03d}"


def bullet_list(lines: List[str]) -> str:
    return "\n".join(f"- {line}" for line in lines) if lines else "- Da compilare"


def numbered_list(lines: List[str]) -> str:
    return "\n".join(f"{i + 1}. {line}" for i, line in enumerate(lines)) if lines else "1. Da compilare"


def multiline_input(label: str) -> List[str]:
    print(f"\n{label}")
    print("Scrivi una riga per volta. Quando hai finito scrivi solo: .")
    lines = []
    while True:
        line = input("> ").strip()
        if line == ".":
            break
        if line:
            lines.append(line)
    return lines


def add_guasto_interactive() -> Path:
    print("=" * 60)
    print("NUOVO GUASTO — Knowledge Base AssetTrace Node")
    print("=" * 60)

    categoria = input("\nCategoria es. stampanti_3d, windows, rete, raspberry, elettronica: ").strip() or "generale"
    titolo = input("\nTitolo breve del guasto: ").strip() or "guasto_senza_titolo"
    sistema = input("\nSistema/macchina coinvolta: ").strip() or "Da definire"
    stato = input("\nStato del caso es. nuovo, ricorrente, risolto, sospetto: ").strip() or "nuovo"

    machine_id = input("\nID macchina collegata, se presente es. MAC-001. Invio per nessuna: ").strip()
    if machine_id:
        machine = get_machine(machine_id)
        if not machine:
            print(f"\nATTENZIONE: macchina {machine_id} non trovata. Il guasto sarà salvato senza collegamento macchina.")
            machine_id = ""
        else:
            print(f"\nCollegamento macchina OK: {machine_id} — {machine.get('name')}")

    segnali = multiline_input("Melma — segnali grezzi osservati")
    ipotesi = multiline_input("Nodi — ipotesi possibili")
    dubbi = multiline_input("Dubbio attivo / cosa non torna")
    test = multiline_input("Test minimi reversibili")
    limiti = multiline_input("Governo — limiti, rischi, cose da NON forzare")

    prossima_azione = input("\nProssima azione minima, reversibile e testabile: ").strip()
    if not prossima_azione:
        prossima_azione = "Osservare meglio il guasto e raccogliere segnali prima di intervenire."

    guasto_id = next_guasto_id()
    folder = GUASTI_DIR / categoria
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{guasto_id}_{slugify(titolo)}.md"

    content = f"""# {guasto_id} — {titolo}

## Stato
{stato}

## Data creazione
{datetime.now().isoformat(timespec="seconds")}

## Sistema
{sistema}

## Macchina collegata
{machine_id or "Non collegata"}

---

## Melma — segnali raccolti
{bullet_list(segnali)}

---

## Nodi — pattern e ipotesi
{numbered_list(ipotesi)}

---

## Dubbio attivo
{bullet_list(dubbi)}

---

## Test minimi reversibili
{numbered_list(test)}

---

## Governo sistemico

### Dominio
Da valutare: gestibile / ingestibile / parzialmente gestibile.

### Impatto
Da valutare: basso / medio / alto.

### Limiti e rischi
{bullet_list(limiti)}

### Regola di sicurezza
Non forzare interventi irreversibili. Se il guasto riguarda corrente, temperatura, dati, sicurezza o parti critiche, procedere solo con test minimi e reversibili.

---

## Ciclo evolutivo AssetTrace

### 1. Osservazione
Raccogliere segnali, contesto, variazioni e rumore.

### 2. Adattamento locale
Provare interventi piccoli, reversibili e circoscritti.

### 3. Espansione se necessaria
Se il problema persiste, ampliare lo spazio di analisi: componenti vicini, cablaggi, software, configurazioni, ambiente.

### 4. Chiusura ciclo
Fissare la diagnosi più probabile e lo stato del caso.

### 5. Passaggio temporale
Ritestare dopo modifica, pausa, riavvio o sostituzione.

### 6. Ottimizzazione
Trasformare il caso in procedura, pattern o regola riutilizzabile.

### 7. Nuovo ciclo
Applicare l'apprendimento a guasti simili.

---

## Prossima azione minima
{prossima_azione}
"""
    path.write_text(content, encoding="utf-8")

    if machine_id:
        add_machine_event(
            machine_id,
            event_type="guasto",
            title=f"Guasto registrato: {guasto_id} — {titolo}",
            description=f"File guasto: {path}",
            impact="medio",
            payload={"guasto_id": guasto_id, "file": str(path)},
        )

    return path
