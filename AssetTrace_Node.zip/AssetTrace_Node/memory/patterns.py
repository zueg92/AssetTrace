import json
import re
from collections import Counter
from typing import Dict, List, Optional

from config import GUASTI_DIR
from memory.store import connect
from memory.parco_macchine import get_machine, list_machines


STATUS_PENALTY = {
    "operativa": 0,
    "attiva": 0,
    "ok": 0,
    "osservazione": 10,
    "manutenzione": 18,
    "guasto": 35,
    "ferma": 32,
    "dismessa": 5,
}

EVENT_TYPE_WEIGHT = {
    "guasto": 9,
    "errore": 7,
    "cambio_stato": 3,
    "manutenzione": 2,
    "controllo": 1,
    "nota": 1,
    "creazione": 0,
}

IMPACT_WEIGHT = {
    "basso": 1,
    "medio": 3,
    "alto": 6,
    "critico": 9,
}

STOPWORDS = {
    "di", "a", "da", "in", "con", "su", "per", "il", "lo", "la", "i", "gli", "le",
    "un", "una", "e", "o", "che", "del", "della", "dei", "delle", "non", "macchina",
    "guasto", "evento", "stato", "aggiornato", "comando", "file"
}


def _norm(text: Optional[str]) -> str:
    return (text or "").strip().lower()


def _risk_label(health: int) -> str:
    if health >= 80:
        return "buono"
    if health >= 60:
        return "osservazione"
    if health >= 40:
        return "manutenzione consigliata"
    return "critico"


def _tokenize(text: str) -> List[str]:
    words = re.findall(r"[a-zA-ZÀ-ÿ0-9_]{3,}", text.lower())
    return [w for w in words if w not in STOPWORDS and not w.isdigit()]


def _fetch_events(machine_id: Optional[str] = None, limit: Optional[int] = None) -> List[Dict]:
    query = """
        SELECT id, timestamp, machine_id, event_type, title, description, impact, payload_json
        FROM machine_events
    """
    params: List = []

    if machine_id:
        query += " WHERE machine_id = ?"
        params.append(machine_id)

    query += " ORDER BY id DESC"

    if limit:
        query += " LIMIT ?"
        params.append(limit)

    with connect() as conn:
        rows = conn.execute(query, params).fetchall()
    return [dict(row) for row in rows]


def scan_guasti_files() -> List[Dict]:
    items: List[Dict] = []
    if not GUASTI_DIR.exists():
        return items

    for path in sorted(GUASTI_DIR.rglob("GUA-*.md")):
        text = path.read_text(encoding="utf-8", errors="ignore")
        title_match = re.search(r"^#\s*(GUA-\d+)\s*[—-]\s*(.+)$", text, flags=re.MULTILINE)
        machine_match = re.search(r"##\s*Macchina collegata\s*\n(.+)", text, flags=re.IGNORECASE)
        status_match = re.search(r"##\s*Stato\s*\n(.+)", text, flags=re.IGNORECASE)

        guasto_id = title_match.group(1).strip() if title_match else path.stem.split("_")[0]
        title = title_match.group(2).strip() if title_match else path.stem
        machine_id = machine_match.group(1).strip() if machine_match else ""
        status = status_match.group(1).strip() if status_match else ""

        if machine_id.lower().startswith("non collegata"):
            machine_id = ""

        items.append({
            "guasto_id": guasto_id,
            "title": title,
            "machine_id": machine_id,
            "status": status,
            "path": str(path),
        })

    return items


def compute_machine_health(machine: Dict) -> Dict:
    machine_id = machine["id"]
    events = _fetch_events(machine_id)
    guasti_files = [g for g in scan_guasti_files() if g.get("machine_id") == machine_id]

    status = _norm(machine.get("status"))
    status_penalty = STATUS_PENALTY.get(status, 8)

    criticality = int(machine.get("criticality") or 3)
    criticality_penalty = max(0, criticality - 1) * 3

    event_penalty = 0
    event_counts = Counter()
    impact_counts = Counter()

    for e in events:
        etype = _norm(e.get("event_type"))
        impact = _norm(e.get("impact"))
        event_counts[etype] += 1
        impact_counts[impact] += 1
        event_penalty += EVENT_TYPE_WEIGHT.get(etype, 2)
        event_penalty += IMPACT_WEIGHT.get(impact, 0)

    event_penalty += len(guasti_files) * 5
    event_penalty = min(event_penalty, 55)

    health = 100 - status_penalty - criticality_penalty - event_penalty
    health = max(0, min(100, int(health)))

    return {
        "machine_id": machine_id,
        "name": machine.get("name"),
        "status": machine.get("status"),
        "criticality": criticality,
        "health": health,
        "risk": _risk_label(health),
        "events_total": len(events),
        "guasti_files": len(guasti_files),
        "event_counts": dict(event_counts),
        "impact_counts": dict(impact_counts),
    }


def analyze_machine_patterns(machine_id: str) -> Dict:
    machine = get_machine(machine_id)
    if not machine:
        return {"ok": False, "error": f"Macchina {machine_id} non trovata"}

    events = _fetch_events(machine_id, limit=50)
    guasti_files = [g for g in scan_guasti_files() if g.get("machine_id") == machine_id]
    health = compute_machine_health(machine)

    event_counts = Counter(_norm(e.get("event_type")) for e in events)
    impact_counts = Counter(_norm(e.get("impact")) for e in events)

    text_blob = " ".join(
        [e.get("title") or "" for e in events]
        + [e.get("description") or "" for e in events]
        + [g.get("title") or "" for g in guasti_files]
    )
    top_terms = Counter(_tokenize(text_blob)).most_common(8)

    signals = []
    if health["health"] < 40:
        signals.append("Health index critico: serve priorità manutentiva.")
    elif health["health"] < 60:
        signals.append("Health index medio-basso: consigliata osservazione attiva.")

    if event_counts.get("guasto", 0) >= 2:
        signals.append("Guasti ricorrenti registrati nello storico eventi.")

    if impact_counts.get("alto", 0) or impact_counts.get("critico", 0):
        signals.append("Sono presenti eventi ad alto impatto.")

    if _norm(machine.get("status")) in {"guasto", "ferma", "manutenzione"}:
        signals.append("Lo stato attuale richiede attenzione operativa.")

    if not signals:
        signals.append("Nessun pattern critico evidente dai dati attuali.")

    return {
        "ok": True,
        "machine": machine,
        "health": health,
        "event_counts": dict(event_counts),
        "impact_counts": dict(impact_counts),
        "top_terms": top_terms,
        "guasti_files": guasti_files,
        "signals": signals,
        "recent_events": events[:8],
    }


def analyze_global_patterns() -> Dict:
    machines = list_machines()
    health_items = [compute_machine_health(m) for m in machines]

    events = _fetch_events(limit=200)
    event_counts = Counter(_norm(e.get("event_type")) for e in events)
    impact_counts = Counter(_norm(e.get("impact")) for e in events)

    text_blob = " ".join(
        [e.get("title") or "" for e in events]
        + [e.get("description") or "" for e in events]
        + [m.get("name") or "" for m in machines]
        + [m.get("notes") or "" for m in machines]
    )
    top_terms = Counter(_tokenize(text_blob)).most_common(12)
    weakest = sorted(health_items, key=lambda x: x["health"])[:5]

    return {
        "machines_total": len(machines),
        "events_total": len(events),
        "event_counts": dict(event_counts),
        "impact_counts": dict(impact_counts),
        "top_terms": top_terms,
        "weakest": weakest,
        "health_items": sorted(health_items, key=lambda x: x["health"]),
    }


def format_health_table() -> str:
    machines = list_machines()
    if not machines:
        return "Nessuna macchina registrata. Usa /addmacchina."

    items = [compute_machine_health(m) for m in machines]
    items = sorted(items, key=lambda x: x["health"])

    lines = [
        "HEALTH INDEX PARCO MACCHINE",
        "",
        "ID       | Health | Rischio                  | Stato        | Crit | Nome",
        "---------|--------|--------------------------|--------------|------|----------------",
    ]

    for item in items:
        lines.append(
            f"{item['machine_id']:<8} | {item['health']:<6} | {item['risk'][:24]:<24} | "
            f"{str(item['status'])[:12]:<12} | {item['criticality']:<4} | {item['name']}"
        )

    return "\n".join(lines)


def format_patterns_report(machine_id: Optional[str] = None) -> str:
    if machine_id:
        analysis = analyze_machine_patterns(machine_id)
        if not analysis.get("ok"):
            return analysis.get("error", "Errore analisi patterns.")

        m = analysis["machine"]
        h = analysis["health"]

        lines = [
            f"PATTERNS — {m['id']} — {m['name']}",
            "",
            f"Health index: {h['health']}/100",
            f"Rischio: {h['risk']}",
            f"Stato: {m.get('status')}",
            f"Criticità: {m.get('criticality')}/5",
            "",
            "Pattern / segnali:",
        ]

        for s in analysis["signals"]:
            lines.append(f"- {s}")

        lines.append("")
        lines.append("Conteggio eventi:")
        if analysis["event_counts"]:
            for k, v in sorted(analysis["event_counts"].items()):
                lines.append(f"- {k or 'non specificato'}: {v}")
        else:
            lines.append("- Nessun evento registrato.")

        lines.append("")
        lines.append("Termini ricorrenti:")
        if analysis["top_terms"]:
            for term, count in analysis["top_terms"]:
                lines.append(f"- {term}: {count}")
        else:
            lines.append("- Nessun termine ricorrente utile.")

        lines.append("")
        lines.append("Guasti markdown collegati:")
        if analysis["guasti_files"]:
            for g in analysis["guasti_files"]:
                lines.append(f"- {g['guasto_id']} — {g['title']} | stato: {g.get('status') or '-'}")
        else:
            lines.append("- Nessun guasto markdown collegato.")

        lines.append("")
        lines.append("Prossima azione minima:")
        if h["health"] < 40:
            lines.append("- Isolare la macchina, leggere eventi recenti e registrare un controllo mirato.")
        elif h["health"] < 60:
            lines.append("- Mettere la macchina in osservazione e aggiungere test minimi reversibili.")
        else:
            lines.append("- Mantenere monitoraggio, aggiornare eventi e guasti se emergono nuovi segnali.")

        return "\n".join(lines)

    analysis = analyze_global_patterns()

    lines = [
        "PATTERNS GLOBALI — PARCO MACCHINE",
        "",
        f"Macchine registrate: {analysis['machines_total']}",
        f"Eventi registrati: {analysis['events_total']}",
        "",
        "Macchine più fragili:",
    ]

    if analysis["weakest"]:
        for item in analysis["weakest"]:
            lines.append(
                f"- {item['machine_id']} — {item['name']} | health {item['health']}/100 | {item['risk']} | stato: {item['status']}"
            )
    else:
        lines.append("- Nessuna macchina registrata.")

    lines.append("")
    lines.append("Eventi ricorrenti:")
    if analysis["event_counts"]:
        for k, v in sorted(analysis["event_counts"].items(), key=lambda x: x[1], reverse=True):
            lines.append(f"- {k or 'non specificato'}: {v}")
    else:
        lines.append("- Nessun evento registrato.")

    lines.append("")
    lines.append("Termini ricorrenti:")
    if analysis["top_terms"]:
        for term, count in analysis["top_terms"]:
            lines.append(f"- {term}: {count}")
    else:
        lines.append("- Nessun termine ricorrente utile.")

    lines.append("")
    lines.append("Prossima azione minima:")
    if analysis["weakest"]:
        first = analysis["weakest"][0]
        lines.append(f"- Aprire /patterns {first['machine_id']} e verificare la macchina più fragile.")
    else:
        lines.append("- Aggiungere macchine e primi eventi per creare dati analizzabili.")

    return "\n".join(lines)


def load_patterns_summary(limit: int = 10) -> List[Dict]:
    machines = list_machines()
    items = [compute_machine_health(m) for m in machines]
    items = sorted(items, key=lambda x: x["health"])[:limit]

    return [
        {
            "machine_id": item["machine_id"],
            "name": item["name"],
            "status": item["status"],
            "criticality": item["criticality"],
            "health": item["health"],
            "risk": item["risk"],
            "events_total": item["events_total"],
            "guasti_files": item["guasti_files"],
        }
        for item in items
    ]
