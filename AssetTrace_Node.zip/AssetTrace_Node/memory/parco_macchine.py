import json
import re
from datetime import datetime
from typing import Dict, List, Optional

from memory.store import connect


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _safe_int(value: str, default: int = 3, minimum: int = 1, maximum: int = 5) -> int:
    try:
        parsed = int(value)
    except Exception:
        return default
    return max(minimum, min(parsed, maximum))


def next_machine_id() -> str:
    """Genera ID progressivi MAC-001, MAC-002, ..."""
    with connect() as conn:
        rows = conn.execute("SELECT id FROM machine_assets WHERE id LIKE 'MAC-%'").fetchall()
    ids = []
    for row in rows:
        match = re.search(r"MAC-(\d+)", row["id"])
        if match:
            ids.append(int(match.group(1)))
    return f"MAC-{max(ids, default=0) + 1:03d}"


def add_machine(
    name: str,
    category: str = "generale",
    model: str = "",
    location: str = "",
    ip_address: str = "",
    controller_url: str = "",
    status: str = "attiva",
    criticality: int = 3,
    notes: str = "",
    metadata: Optional[Dict] = None,
) -> str:
    machine_id = next_machine_id()
    timestamp = now()
    metadata = metadata or {}

    with connect() as conn:
        conn.execute(
            """
            INSERT INTO machine_assets(
                id, name, category, model, location, ip_address, controller_url,
                status, criticality, created_at, updated_at, notes, metadata_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                machine_id,
                name.strip() or "Macchina senza nome",
                category.strip() or "generale",
                model.strip(),
                location.strip(),
                ip_address.strip(),
                controller_url.strip(),
                status.strip() or "attiva",
                int(criticality),
                timestamp,
                timestamp,
                notes.strip(),
                json.dumps(metadata, ensure_ascii=False),
            ),
        )
        conn.execute(
            """
            INSERT INTO machine_events(timestamp, machine_id, event_type, title, description, impact, payload_json)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                timestamp,
                machine_id,
                "creazione",
                "Macchina aggiunta al parco macchine",
                f"Aggiunta macchina {name}",
                "basso",
                json.dumps({"status": status, "criticality": criticality}, ensure_ascii=False),
            ),
        )
        conn.commit()

    return machine_id


def add_machine_interactive() -> str:
    print("=" * 60)
    print("NUOVA MACCHINA — Parco Macchine AssetTrace")
    print("=" * 60)

    category = input("\nCategoria es. stampante_3d, raspberry, server, rete, pc, sensore: ").strip() or "generale"
    name = input("\nNome macchina es. Chiron 1, Raspberry OctoPrint, NAS: ").strip() or "Macchina senza nome"
    model = input("\nModello / versione hardware: ").strip()
    location = input("\nPosizione fisica es. laboratorio, casa, reparto: ").strip()
    ip_address = input("\nIP locale, se presente: ").strip()
    controller_url = input("\nURL controllo es. OctoPrint/dashboard, se presente: ").strip()
    status = input("\nStato es. attiva, osservazione, manutenzione, ferma, dismessa: ").strip() or "attiva"
    criticality = _safe_int(input("\nCriticità 1-5 (1 bassa, 5 critica): ").strip(), default=3)
    notes = input("\nNote sintetiche: ").strip()

    machine_id = add_machine(
        name=name,
        category=category,
        model=model,
        location=location,
        ip_address=ip_address,
        controller_url=controller_url,
        status=status,
        criticality=criticality,
        notes=notes,
    )

    return machine_id


def list_machines(status: Optional[str] = None) -> List[Dict]:
    query = "SELECT * FROM machine_assets"
    params: List[str] = []

    if status:
        query += " WHERE lower(status) = lower(?)"
        params.append(status)

    query += " ORDER BY criticality DESC, updated_at DESC, id ASC"

    with connect() as conn:
        rows = conn.execute(query, params).fetchall()
    return [dict(row) for row in rows]


def get_machine(machine_id: str) -> Optional[Dict]:
    with connect() as conn:
        row = conn.execute("SELECT * FROM machine_assets WHERE id = ?", (machine_id.strip(),)).fetchone()
    return dict(row) if row else None


def search_machines(text: str) -> List[Dict]:
    like = f"%{text.strip()}%"
    with connect() as conn:
        rows = conn.execute(
            """
            SELECT * FROM machine_assets
            WHERE id LIKE ? OR name LIKE ? OR category LIKE ? OR model LIKE ? OR location LIKE ? OR notes LIKE ?
            ORDER BY criticality DESC, updated_at DESC
            """,
            (like, like, like, like, like, like),
        ).fetchall()
    return [dict(row) for row in rows]


def update_machine_status(machine_id: str, status: str, note: str = "") -> bool:
    machine = get_machine(machine_id)
    if not machine:
        return False

    timestamp = now()
    with connect() as conn:
        conn.execute(
            "UPDATE machine_assets SET status = ?, updated_at = ? WHERE id = ?",
            (status.strip(), timestamp, machine_id),
        )
        conn.execute(
            """
            INSERT INTO machine_events(timestamp, machine_id, event_type, title, description, impact, payload_json)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                timestamp,
                machine_id,
                "cambio_stato",
                f"Cambio stato: {status}",
                note,
                "medio",
                json.dumps({"old_status": machine.get("status"), "new_status": status}, ensure_ascii=False),
            ),
        )
        conn.commit()
    return True


def add_machine_event(machine_id: str, event_type: str, title: str, description: str = "", impact: str = "medio", payload: Optional[Dict] = None) -> bool:
    if not get_machine(machine_id):
        return False

    timestamp = now()
    with connect() as conn:
        conn.execute(
            """
            INSERT INTO machine_events(timestamp, machine_id, event_type, title, description, impact, payload_json)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                timestamp,
                machine_id,
                event_type.strip() or "evento",
                title.strip() or "Evento macchina",
                description.strip(),
                impact.strip() or "medio",
                json.dumps(payload or {}, ensure_ascii=False),
            ),
        )
        conn.execute("UPDATE machine_assets SET updated_at = ? WHERE id = ?", (timestamp, machine_id))
        conn.commit()
    return True


def list_machine_events(machine_id: str, limit: int = 10) -> List[Dict]:
    with connect() as conn:
        rows = conn.execute(
            """
            SELECT timestamp, event_type, title, description, impact, payload_json
            FROM machine_events
            WHERE machine_id = ?
            ORDER BY id DESC
            LIMIT ?
            """,
            (machine_id, limit),
        ).fetchall()
    return [dict(row) for row in rows]


def format_machines_table(machines: List[Dict]) -> str:
    if not machines:
        return "Nessuna macchina registrata. Usa /addmacchina."

    lines = ["ID       | Crit | Stato        | Categoria      | Nome", "---------|------|--------------|----------------|----------------"]
    for m in machines:
        lines.append(
            f"{m['id']:<8} | {m['criticality']:<4} | {m['status'][:12]:<12} | {m['category'][:14]:<14} | {m['name']}"
        )
    return "\n".join(lines)


def format_machine_detail(machine: Dict, events: Optional[List[Dict]] = None) -> str:
    events = events or []
    lines = [
        f"# {machine['id']} — {machine['name']}",
        "",
        f"Categoria: {machine.get('category') or '-'}",
        f"Modello: {machine.get('model') or '-'}",
        f"Posizione: {machine.get('location') or '-'}",
        f"IP: {machine.get('ip_address') or '-'}",
        f"URL controllo: {machine.get('controller_url') or '-'}",
        f"Stato: {machine.get('status') or '-'}",
        f"Criticità: {machine.get('criticality') or '-'} / 5",
        f"Creata: {machine.get('created_at') or '-'}",
        f"Aggiornata: {machine.get('updated_at') or '-'}",
        f"Note: {machine.get('notes') or '-'}",
        "",
        "## Eventi recenti",
    ]

    if not events:
        lines.append("- Nessun evento registrato.")
    else:
        for e in events:
            lines.append(f"- {e['timestamp']} | {e['event_type']} | {e['title']} | impatto: {e.get('impact') or '-'}")
            if e.get("description"):
                lines.append(f"  {e['description']}")

    return "\n".join(lines)


def load_machines_summary(limit: int = 20) -> List[Dict]:
    machines = list_machines()[:limit]
    summary = []
    for m in machines:
        summary.append({
            "id": m["id"],
            "name": m["name"],
            "category": m["category"],
            "model": m.get("model"),
            "location": m.get("location"),
            "status": m["status"],
            "criticality": m["criticality"],
            "ip_address": m.get("ip_address"),
            "controller_url": m.get("controller_url"),
            "notes": m.get("notes"),
        })
    return summary


def seed_example_machines_if_empty() -> None:
    """Crea esempi solo se il parco è completamente vuoto."""
    if list_machines():
        return
    add_machine(
        name="Anycubic Chiron",
        category="stampante_3d",
        model="Anycubic Chiron",
        location="Da definire",
        status="osservazione",
        criticality=4,
        notes="Esempio iniziale: collegare qui guasti tipo T0 abnormal, mesh, cablaggi, OctoPrint.",
    )
    add_machine(
        name="Raspberry Pi OctoPrint",
        category="raspberry",
        model="Raspberry Pi 3",
        location="Da definire",
        status="attiva",
        criticality=4,
        notes="Nodo locale per OctoPrint/dashboard/AssetTrace. Aggiornare IP quando noto.",
    )
