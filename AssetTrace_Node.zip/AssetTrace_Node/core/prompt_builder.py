import json
from typing import Dict, List, Optional

from config import ROOT, SYSTEM_PROMPT
from tools.docs_loader import load_docs_text
from memory.parco_macchine import load_machines_summary
from memory.patterns import load_patterns_summary


def build_messages(user_text: str, recent_memory: List[Dict], governance: Dict, web_context: Optional[str] = None) -> List[Dict[str, str]]:
    docs = load_docs_text(ROOT)
    machines = load_machines_summary(20)
    patterns = load_patterns_summary(10)

    web_block = ""
    if web_context:
        web_block = f"""

CONTESTO PARTE 4 — RICERCA WEB REAL-TIME:
{web_context}
"""

    context = f"""
DOCUMENTI FONDATIVI DI ANTINEA:
{docs}

MEMORIA RECENTE:
{json.dumps(recent_memory, ensure_ascii=False, indent=2)}

PARCO MACCHINE REGISTRATO:
{json.dumps(machines, ensure_ascii=False, indent=2)}

PATTERNS / HEALTH INDEX:
{json.dumps(patterns, ensure_ascii=False, indent=2)}

VALUTAZIONE DI GOVERNO:
{json.dumps(governance, ensure_ascii=False, indent=2)}
{web_block}

ISTRUZIONE OPERATIVA:
Rispondi usando, quando utile, questa struttura:
1. Osservazione
2. Melma / Nodi / Legante
3. Gestibile / Ingestibile
4. Ciclo attuale
5. Parte 4 — Percezione esterna / ricerca web, se rilevante
6. Prossima azione minima

Regole:
- Distingui memoria interna, guasti, parco macchine, documenti fondativi e fonti web.
- Quando l'utente cita una macchina, prova a collegarla al parco macchine registrato.
- Non inventare fonti.
- Se il nodo locale non ha accesso a internet, proponi query e criteri di verifica.
- Le azioni critiche devono restare confermate dall'utente.
"""

    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "system", "content": context},
        {"role": "user", "content": user_text},
    ]
