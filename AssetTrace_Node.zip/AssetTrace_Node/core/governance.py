from typing import Dict

RISK_WORDS = [
    "cancella tutto", "formatta", "elimina", "irreversibile",
    "farmaco", "diagnosi", "legale", "soldi", "investire",
    "corrente", "alta tensione", "firmware", "flash firmware",
]

SURPRISE_WORDS = [
    "errore", "non funziona", "non torna", "strano", "bloccato",
    "crash", "incoerenza", "anomalia", "guasto", "abnormal",
]

WEB_WORDS = [
    "cerca online", "cerca su internet", "ricerca web", "web", "internet",
    "aggiornato", "ultima versione", "prezzo", "api", "firmware",
    "documentazione", "fonti", "verifica online", "controlla online",
]


def governance_check(user_text: str) -> Dict[str, object]:
    text = user_text.lower()

    risk = any(word in text for word in RISK_WORDS)
    surprise = any(word in text for word in SURPRISE_WORDS)
    web_needed = any(word in text for word in WEB_WORDS)

    if risk:
        domain = "potenzialmente ingestibile o ad alto impatto"
        impact = "alto"
        action = "non forzare; chiedere conferma; proporre passi reversibili e testabili"
    elif web_needed:
        domain = "gestibile con percezione esterna da verificare"
        impact = "medio"
        action = "attivare Parte 4: separare memoria interna, fonti esterne, freschezza e incertezza"
    elif surprise:
        domain = "gestibile con dubbio attivo"
        impact = "medio"
        action = "osservare, isolare il problema, fare test minimo e reversibile"
    else:
        domain = "gestibile"
        impact = "basso/medio"
        action = "adattamento locale"

    return {
        "dominio": domain,
        "impatto": impact,
        "azione": action,
        "parte_4_web_rilevante": web_needed,
        "sorpresa_o_guasto": surprise,
        "rischio_alto": risk,
    }


def should_auto_web(user_text: str) -> bool:
    text = user_text.lower()
    explicit = [
        "cerca online", "cerca su internet", "verifica online", "ricerca web",
        "controlla online", "guarda online", "fonti online", "aggiornato online",
        "ultima versione", "prezzo aggiornato", "documentazione aggiornata",
    ]
    return any(word in text for word in explicit)
