import json
import socket
import urllib.error
import urllib.request
from typing import Dict, List

from config import MODEL, OLLAMA_URL, OLLAMA_TIMEOUT


def ask_ollama(messages: List[Dict[str, str]]) -> str:
    payload = {
        "model": MODEL,
        "messages": messages,
        "stream": False,
        "options": {"temperature": 0.35, "num_ctx": 8192},
    }

    data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        OLLAMA_URL,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=OLLAMA_TIMEOUT) as response:
            raw = response.read().decode("utf-8")
            result = json.loads(raw)
            return result["message"]["content"].strip()

    except KeyboardInterrupt:
        return (
            "CHIAMATA A OLLAMA INTERROTTA DALL'UTENTE.\n\n"
            "La richiesta era stata inviata al modello ma la risposta non era ancora arrivata.\n"
            "Prova /ollama per verificare il servizio, oppure fai una domanda più specifica."
        )

    except urllib.error.URLError as e:
        return (
            "ERRORE: non riesco a collegarmi a Ollama.\n\n"
            f"Dettaglio: {e}\n\n"
            "Controlla in PowerShell:\n"
            "ollama serve\n"
            "ollama list\n"
            "ollama run llama3.2:3b"
        )

    except TimeoutError:
        return (
            f"ERRORE: Ollama non ha risposto entro {OLLAMA_TIMEOUT} secondi.\n"
            "Probabile modello lento o contesto troppo pesante."
        )

    except socket.timeout:
        return (
            f"ERRORE: timeout verso Ollama dopo {OLLAMA_TIMEOUT} secondi.\n"
            "Ollama è raggiungibile ma non completa la risposta in tempo."
        )

    except Exception as e:
        return f"ERRORE imprevisto: {e}"


def check_ollama() -> Dict:
    base_url = OLLAMA_URL.replace("/api/chat", "")
    tags_url = base_url + "/api/tags"

    request = urllib.request.Request(
        tags_url,
        headers={"Content-Type": "application/json"},
        method="GET",
    )

    try:
        with urllib.request.urlopen(request, timeout=5) as response:
            raw = response.read().decode("utf-8")
            data = json.loads(raw)
            models = [m.get("name", "") for m in data.get("models", [])]
            return {
                "ok": True,
                "models": models,
                "model_configurato": MODEL,
                "model_presente": any(m == MODEL or m.startswith(MODEL) for m in models),
            }
    except Exception as e:
        return {
            "ok": False,
            "error": str(e),
            "model_configurato": MODEL,
            "models": [],
        }
